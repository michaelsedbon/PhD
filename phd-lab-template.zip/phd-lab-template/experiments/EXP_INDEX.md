# Experiment Index

Quick-reference index for the AI assistant. Scan this file to find relevant experiments
before diving into individual `experiments/EXP_XXX/summary.md` files.

---

<!-- Entries are added as experiments are synced from Notion or created locally. -->
<!-- Format:
## EXP_XXX — Experiment Title
**Start Date:** YYYY-MM-DD
**Status:** Active / Completed

Brief summary of the experiment's goals, methods, and key findings.
-->
