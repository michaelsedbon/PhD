# Paper Index

Quick-reference index for the AI assistant. When a literature question arises,
scan the summaries below to decide which full paper(s) to load from this folder.

---

<!-- Add paper summaries here as papers are synced from your Notion bibliography. -->
<!-- Format:
## <Paper Title>
**File:** <filename.txt>
**Subjects:** <comma-separated tags>
**URL:** <source URL>

Summary paragraph covering the core method, key results, relevance, and connections to other papers.
-->
