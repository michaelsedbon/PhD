---
description: How to apply changes to the LaTeX document or any file
---

## Rules

1. **Apply edits inline.** Use the code edit tools (replace_file_content /
   multi_replace_file_content) to modify the file directly. This shows the
   proposed changes as red/green inline diffs in the user's open editor tab,
   where they can accept or reject each change. Do NOT present diffs in a
   separate artifact or chat message.
2. **Wait for approval.** The user will accept or reject the inline diff in
   their editor. Do not proceed until they confirm.
3. **Compile after applying.** After applying approved changes to `.tex` or
   `.bib` files, run `./compile.sh` to verify the document builds cleanly.
4. **Red text for new ideas.** Wrap speculative or unverified text in
   `\textcolor{BrickRed}{...}` and use `\cite{missing_ref}` as a placeholder
   citation.
5. **Scientific tone.** Maintain precise terminology, italicised species
   names, and concise sentence structure throughout.
