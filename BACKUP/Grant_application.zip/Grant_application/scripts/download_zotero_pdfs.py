#!/usr/bin/env python3
"""
Download PDFs from a Zotero library into a local subfolder.

Only downloads new PDFs that are not already present locally.
Uses the same Zotero API credentials as sync_zotero.py.
"""

import os
import re
import sys
import requests
import yaml

# --- CONFIGURATION (from project.yaml) ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
config_path = os.path.join(PROJECT_DIR, 'project.yaml')

with open(config_path) as f:
    config = yaml.safe_load(f)

ZOTERO_API_KEY = os.environ.get('ZOTERO_API_KEY', config['zotero']['api_key'])
ZOTERO_LIBRARY_ID = os.environ.get('ZOTERO_LIBRARY_ID', str(config['zotero']['library_id']))
ZOTERO_LIBRARY_TYPE = os.environ.get('ZOTERO_LIBRARY_TYPE', config['zotero']['library_type'])
ZOTERO_COLLECTION_ID = os.environ.get('ZOTERO_COLLECTION_ID', config['zotero'].get('collection_id', ''))
PDF_DIR = os.path.join(PROJECT_DIR, 'papers')

BASE_URL = f"https://api.zotero.org/{ZOTERO_LIBRARY_TYPE}s/{ZOTERO_LIBRARY_ID}"
HEADERS = {
    'Zotero-API-Key': ZOTERO_API_KEY,
    'Zotero-API-Version': '3',
}


def sanitize_filename(name):
    """Remove or replace characters that are invalid in filenames."""
    name = re.sub(r'[<>:"/\\|?*]', '_', name)
    name = name.strip('. ')
    return name[:200]  # Limit length


def get_all_items():
    """Fetch all top-level items from the library (paginated)."""
    items = []
    start = 0
    limit = 100

    if ZOTERO_COLLECTION_ID:
        endpoint = f"{BASE_URL}/collections/{ZOTERO_COLLECTION_ID}/items/top"
    else:
        endpoint = f"{BASE_URL}/items/top"

    while True:
        params = {'start': start, 'limit': limit, 'format': 'json'}
        resp = requests.get(endpoint, headers=HEADERS, params=params)
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            break
        items.extend(batch)
        # Check if there are more items
        total = int(resp.headers.get('Total-Results', len(items)))
        start += limit
        if start >= total:
            break

    return items


def get_children(item_key):
    """Get child items (attachments) of a given item."""
    url = f"{BASE_URL}/items/{item_key}/children"
    params = {'format': 'json'}
    resp = requests.get(url, headers=HEADERS, params=params)
    resp.raise_for_status()
    return resp.json()


def download_attachment(item_key, dest_path):
    """Download the file content of an attachment item."""
    url = f"{BASE_URL}/items/{item_key}/file"
    resp = requests.get(url, headers=HEADERS, allow_redirects=True)
    resp.raise_for_status()

    with open(dest_path, 'wb') as f:
        f.write(resp.content)


def make_pdf_filename(item_data):
    """
    Build a filename from the item metadata:
      FirstAuthor_Year_ShortTitle.pdf
    """
    creators = item_data.get('creators', [])
    if creators:
        first = creators[0].get('lastName', creators[0].get('name', 'Unknown'))
    else:
        first = 'Unknown'

    year = item_data.get('date', '')[:4] or 'NoDate'
    title = item_data.get('title', 'Untitled')

    # Shorten title to first few words
    short_title = '_'.join(title.split()[:5])
    filename = f"{first}_{year}_{short_title}.pdf"
    return sanitize_filename(filename)


def main():
    os.makedirs(PDF_DIR, exist_ok=True)

    # Existing PDFs (by filename) — skip re-downloading
    existing = set(os.listdir(PDF_DIR))

    print(f"Fetching items from Zotero library {ZOTERO_LIBRARY_ID}...")
    items = get_all_items()
    print(f"Found {len(items)} top-level items.")

    downloaded = 0
    skipped = 0
    no_pdf = 0

    for item in items:
        data = item.get('data', {})
        item_key = data.get('key', item.get('key', ''))
        item_title = data.get('title', 'Untitled')

        # Build the expected filename for this item
        pdf_name = make_pdf_filename(data)

        if pdf_name in existing:
            skipped += 1
            continue

        # Look for PDF attachments among children
        try:
            children = get_children(item_key)
        except Exception as e:
            print(f"  ⚠ Could not fetch children for '{item_title}': {e}")
            continue

        pdf_attachment = None
        for child in children:
            child_data = child.get('data', {})
            content_type = child_data.get('contentType', '')
            link_mode = child_data.get('linkMode', '')
            if content_type == 'application/pdf' and link_mode in ('imported_file', 'imported_url'):
                pdf_attachment = child_data
                break

        if not pdf_attachment:
            no_pdf += 1
            continue

        attachment_key = pdf_attachment.get('key', '')
        dest = os.path.join(PDF_DIR, pdf_name)

        try:
            print(f"  ↓ Downloading: {pdf_name}")
            download_attachment(attachment_key, dest)
            downloaded += 1
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                print(f"  ⚠ No file stored on Zotero servers for '{item_title}' (linked-only?)")
            else:
                print(f"  ✗ Failed to download '{item_title}': {e}")
        except Exception as e:
            print(f"  ✗ Failed to download '{item_title}': {e}")

    print(f"\nDone! Downloaded: {downloaded}, Already present: {skipped}, No PDF available: {no_pdf}")


if __name__ == '__main__':
    main()
