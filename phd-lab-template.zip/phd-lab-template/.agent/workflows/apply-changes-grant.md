---
description: How to apply changes to a LaTeX grant document or any file
---

# Apply Changes Workflow — MANDATORY

> **⚠️ ABSOLUTE RULE: NEVER modify any file in a grant proposal project without showing the proposed diff to the user FIRST and receiving explicit approval.**

## Steps

1. **Propose changes as a diff block in chat.** Show the exact `diff` of what you plan to change.
2. **Wait for explicit user approval.** Do NOT proceed without a clear "yes", "ok", "apply", or similar.
3. **Only after approval**, apply the changes using code edit tools.
4. The user will verify in **VS Code's git diff view**.
5. If rejected, revise and re-propose — do NOT apply.

## Applies To

- ALL files in the grant proposal folder
- Especially `.tex`, `.bib`, or `.yaml` files
- No exceptions, even for "small" or "obvious" changes
