---
description: Give the user a guided tour of the workspace — what it can do, how to use it, and what workflows are available
---

# Workspace Tour

Use this workflow when the user asks "what can I do?", "how does this work?", "show me around", or similar.

## 1. Introduction

> This is your **AI-powered lab workspace**. I'm your lab assistant — I can help you manage papers, track experiments, write grant proposals, and more.
>
> Everything is connected to your **Notion** databases and **Zotero** library. I'll sync data automatically when you ask.

## 2. Explain the Core Workflows

Go through each one with a brief, friendly explanation:

> Here's what you can ask me to do:
>
> ### 📚 Literature & Papers
> - **`/sync-bibliography`** — I'll pull new papers from your Notion bibliography, download PDFs, extract the text, and create summaries. Then you can ask me questions about any paper.
> - **"Find papers about X"** — I'll search citation networks via Semantic Scholar to find related work.
> - **"What does [paper] say about [topic]?"** — I'll read the actual paper text and answer with quotes.
> - I **never cite a paper without reading it first**. If I can't download it, I'll tell you.
>
> ### 🧪 Experiments
> - **`/sync-experiments`** — Pull experiment entries from your Notion lab notebook.
> - **`/update-experiment`** — Log new results, data, or analysis to an experiment. I'll update both the local file and the Notion page.
> - **`/push-experiment-to-notion`** — Push all local experiment documents to Notion with full formatting.
>
> ### 📝 Grant Proposals
> - **`/new-grant-project`** — I'll scaffold a complete LaTeX grant proposal with Zotero integration.
> - **`/compile-grant`** — Compile the LaTeX to PDF + DOCX.
> - I always show you a diff before editing any document — you approve before I change anything.
>
> ### 🔄 Daily Catch-Up
> - **`/catch-up`** — Sync everything (papers + experiments) and report what's new. Great for starting your day.

## 3. Explain the Folder Structure

> Here's how your workspace is organised:
>
> | Folder | What's inside |
> |--------|-------------|
> | `papers/` | Your downloaded PDFs |
> | `papers_txt/` | Extracted text (so I can search them) |
> | `experiments/` | One folder per experiment, with summaries and data |
> | `scripts/` | Python scripts that power the sync tools |
> | `grant_template/` | Tools for creating LaTeX grant proposals |
> | `applications/` | Lab web applications (if you build any) |
> | `.agent/` | My configuration — workflows, skills, and memory |

## 4. Offer Next Steps

> **What would you like to do first?**
>
> 1. 📚 Sync your bibliography — `/sync-bibliography`
> 2. 🧪 Sync your experiments — `/sync-experiments`
> 3. 🔄 Do a full catch-up — `/catch-up`
> 4. 📝 Start a grant proposal — `/new-grant-project`
> 5. Something else — just ask!
