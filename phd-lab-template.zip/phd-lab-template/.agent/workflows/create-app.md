---
description: How to create a new application in the lab workspace
---
// turbo-all

# Create a New Application

Follow this workflow whenever building a new app for the lab workspace.

## 1. Scaffold the app directory

Create a folder under `applications/<app-slug>/` with two sub-folders:
- `server/`  — Python FastAPI backend (if needed)
- `dashboard/` — Next.js frontend

```bash
mkdir -p applications/<app-slug>/server
mkdir -p applications/<app-slug>/dashboard
```

## 2. Initialise the frontend

```bash
cd applications/<app-slug>/dashboard
npx -y create-next-app@latest ./ --ts --tailwind --eslint --app --src-dir --no-import-alias --skip-install
npm install
npx shadcn@latest init -d   # answer "new-york", base-color "zinc", css-variables yes
```

Set dark mode by adding `className="dark"` on the `<html>` tag in `layout.tsx`.

## 3. Initialise the backend (if applicable)

```bash
cd applications/<app-slug>/server
python3 -m venv .venv && source .venv/bin/activate
pip install fastapi 'uvicorn[standard]' websockets numpy scipy
```

Create `main.py`, `requirements.txt`, and any domain modules.

## 4. Write per-app docs

### README.md
Put a `README.md` in `applications/<app-slug>/` with:
- **What it does** (one paragraph)
- **Tech stack** (backend, frontend, key libs)
- **How to run** (exact commands for backend + frontend)
- **Key config** (ports, env vars, hardware)
- **Architecture** (short description, key files)

### CATCHUP.md
Also create `applications/<app-slug>/CATCHUP.md` — this is a **living changelog** you update every time you make changes. Format:

```markdown
# <App Name> — Catchup

## YYYY-MM-DD — <summary>
- What was changed
- Why
- Any gotchas or decisions made
```

**Rule:** Every time you edit any file in the app, append an entry to CATCHUP.md.

## 5. Update the applications index

Edit `applications/INDEX.md` and add a row to the table:

| App | Slug | Port(s) | Status | Description |
|-----|------|---------|--------|-------------|

## 6. Register in the launcher

Add a card entry in `applications/launcher/src/lib/apps.ts` with:
- `slug`, `name`, `description`, `icon`, `backendPort`, `frontendPort`, `status`

## 7. Build & verify

```bash
# Backend
cd applications/<app-slug>/server
python3 -m uvicorn main:app --port <PORT>

# Frontend
cd applications/<app-slug>/dashboard
npm run build && npm run dev -- -p <PORT>
```

Open the app in the browser, verify it works, then update CATCHUP.md.

## 8. Commit convention

Use commit messages like: `[<app-slug>] <description>`
