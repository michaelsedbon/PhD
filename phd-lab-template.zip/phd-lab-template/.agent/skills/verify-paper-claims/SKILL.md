---
name: verify-paper-claims
description: When recommending or citing a paper, download it first, extract text, verify claims against content
---

# Verify Paper Claims

**This is a mandatory behavior** — follow it EVERY TIME you recommend, cite, or reference a specific paper to the user.

## When to use

Whenever you are about to:
- Recommend a paper to read
- Cite a paper to support a claim
- Reference a specific finding or method from a paper

## Procedure

### 0. Check if you already have it

Before downloading anything, check if the paper already exists:
- Read `papers_txt/INDEX.md` — the user's paper collection
- Read `agent_papers_txt/INDEX.md` — papers you previously downloaded
- Check `papers_txt/` and `agent_papers_txt/` for matching `.txt` files

If found, **skip to step 3** (read and verify) — no need to download again.

### 1. Download the paper

Before making your claim, try to download the PDF:

```bash
python3 -c "
import sys; sys.path.insert(0, 'scripts')
from fetch_papers import download_from_scihub, sanitize_filename

doi = '<DOI or URL>'
title = '<Paper Title>'
output = f'agent_papers/{sanitize_filename(title)}.pdf'
success = download_from_scihub(doi, output)
print('Downloaded' if success else 'Failed')
"
```

### 2. Add to Zotero

After downloading, add the paper to the "AI Agent" Zotero collection:

```python
import yaml, requests

with open('config.yaml') as f:
    config = yaml.safe_load(f)

zotero = config['zotero']
headers = {
    'Zotero-API-Key': zotero['api_key'],
    'Zotero-API-Version': '3',
    'Content-Type': 'application/json',
}

item = [{
    'itemType': 'journalArticle',
    'title': '<Paper Title>',
    'url': 'https://doi.org/<DOI>',
    'collections': [zotero['agent_collection_id']],
}]

resp = requests.post(
    f"https://api.zotero.org/users/{zotero['library_id']}/items",
    headers=headers, json=item
)
```

### 3. Extract text

If download succeeded, extract the text:

```bash
python3 -c "
import subprocess
input_pdf = 'agent_papers/<filename>.pdf'
output_txt = 'agent_papers_txt/<filename>.txt'
subprocess.run(['python3', '-c', '''
import fitz  # PyMuPDF
doc = fitz.open(\"'\" + input_pdf + \"'\")
text = chr(10).join(page.get_text() for page in doc)
with open(\"'\" + output_txt + \"'\", \"w\") as f:
    f.write(text)
print(f\"Extracted {len(text)} chars\")
'''])
"
```

Or if PyMuPDF is not available, use pdftotext:
```bash
pdftotext agent_papers/<filename>.pdf agent_papers_txt/<filename>.txt
```

### 3. Read and verify

Read the extracted text to verify your claim is actually supported:

```python
# Read the text file and search for the specific claim
view_file('agent_papers_txt/<filename>.txt')
```

### 4. Update the index

Add the paper to `agent_papers_txt/INDEX.md`:

```markdown
## <Paper Title>
- **Authors:** ...
- **Year:** ...
- **DOI:** ...
- **Downloaded:** YYYY-MM-DD
- **Cited in context of:** <what you were discussing>
- **Key finding verified:** <the specific claim you verified>
- **File:** `<filename>.txt`
```

### 5. Respond to the user

Only THEN make your recommendation/citation, noting that you verified it:

> "I downloaded and checked [Paper Title] — it confirms that [specific claim]. Specifically, the authors state: '[direct quote]'."

## Important

- If the download fails (Sci-Hub unreachable), **say so explicitly** — don't pretend you verified it
- If the paper doesn't support your claim, **correct yourself** before responding
- PDFs go in `agent_papers/`, text extracts in `agent_papers_txt/`
- This is separate from the user's `papers/` folder — don't mix them
