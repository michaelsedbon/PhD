#!/bin/zsh
# ──────────────────────────────────────────────────────────────
# watch_zotero.sh — Background watcher for Zotero paper sync
#
# Runs in a loop every INTERVAL seconds:
#   1. Syncs bibliography from Zotero  →  maimonide.bib
#   2. Downloads new PDFs              →  papers/
#   3. Extracts text from new PDFs     →  papers_txt/
#   4. Updates INDEX.md with stubs for new papers
#   5. Removes PDFs/TXTs/INDEX entries for papers no longer in bib
#
# Usage:
#   ./scripts/watch_zotero.sh           # foreground (Ctrl-C to stop)
#   ./scripts/watch_zotero.sh &         # background
#   ./scripts/watch_zotero.sh --once    # run once and exit
# ──────────────────────────────────────────────────────────────
eval "$(/usr/libexec/path_helper)"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PAPERS_DIR="$PROJECT_DIR/papers"
TXT_DIR="$PROJECT_DIR/papers_txt"
INDEX="$TXT_DIR/INDEX.md"
BIB_FILE="$PROJECT_DIR/$(python3 -c "import yaml; print(yaml.safe_load(open('$PROJECT_DIR/project.yaml'))['project']['bib_file'])")"
INTERVAL=60  # seconds between checks

RUN_ONCE=false
[[ "$1" == "--once" ]] && RUN_ONCE=true

# Ensure output directories exist
mkdir -p "$PAPERS_DIR" "$TXT_DIR"

# ── helpers ──────────────────────────────────────────────────

log() { echo "[$(date '+%H:%M:%S')] $*"; }

extract_text() {
    local pdf="$1"
    local txt="$2"
    python3 -c "
import sys
from PyPDF2 import PdfReader

try:
    reader = PdfReader('$pdf')
    text = []
    for page in reader.pages:
        t = page.extract_text()
        if t:
            text.append(t)
    with open('$txt', 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(text))
    print(f'  ✓ Extracted {len(reader.pages)} pages → $(basename "$txt")')
except Exception as e:
    print(f'  ⚠ Failed to extract text: {e}', file=sys.stderr)
    sys.exit(1)
"
}

add_index_stub() {
    local txt_file="$1"
    local basename_txt="$(basename "$txt_file")"

    # Skip if already in INDEX.md
    if grep -qF "$basename_txt" "$INDEX" 2>/dev/null; then
        return
    fi

    local stem="${basename_txt%.txt}"
    local author="$(echo "$stem" | cut -d'_' -f1)"
    local year="$(echo "$stem" | cut -d'_' -f2)"
    local title_words="$(echo "$stem" | cut -d'_' -f3- | tr '_' ' ')"

    cat >> "$INDEX" <<EOF

---

## ${author} et al. ${year}
**File:** \`${basename_txt}\`
**Citation key:** *(pending — run INDEX update)*
**Title:** ${title_words}

*(Auto-generated stub — update summary after reviewing the paper.)*
EOF
    log "  📝 Added INDEX stub for $basename_txt"
}

remove_index_entry() {
    local txt_file="$1"
    local basename_txt="$(basename "$txt_file")"

    if ! grep -qF "$basename_txt" "$INDEX" 2>/dev/null; then
        return
    fi

    # Remove the block: from the --- before the entry to the next ---
    python3 -c "
import re

with open('$INDEX', 'r') as f:
    content = f.read()

# Split into sections by ---
sections = re.split(r'\n---\n', content)
filtered = []
for s in sections:
    if '$basename_txt' not in s:
        filtered.append(s)

with open('$INDEX', 'w') as f:
    f.write('\n---\n'.join(filtered))
"
    log "  🗑  Removed INDEX entry for $basename_txt"
}

# Match a PDF/TXT filename to a bib entry using author+title fuzzy match
file_matches_bib() {
    local filename="$1"
    python3 -c "
import re, sys

filename = '$filename'
stem = filename.replace('.pdf','').replace('.txt','')
parts = stem.split('_')
file_author = parts[0].lower() if parts else ''

with open('$BIB_FILE') as f:
    bib = f.read()

entries = []
for m in re.finditer(r'@\w+\{([^,]+),\s*(.*?)(?=\n@|\Z)', bib, re.DOTALL):
    key, block = m.group(1), m.group(2)
    am = re.search(r'author\s*=\s*\{(.+?)\}', block)
    author = ''
    if am:
        raw = am.group(1).split(',')[0].split(' and ')[0].strip()
        author = (raw.split(',')[0] if ',' in raw else raw.split()[-1] if raw.split() else '').lower()
    tm = re.search(r'title\s*=\s*\{(.+?)\}', block)
    title_words = set(re.sub(r'[{}\\\\]', '', tm.group(1)).lower().split()[:5]) if tm else set()
    entries.append({'key': key, 'author': author, 'title_words': title_words})

file_words = set(w.lower() for w in parts[2:])

for e in entries:
    if e['author'][:4] == file_author[:4] or file_author[:4] == e['author'][:4]:
        score = len(e['title_words'] & file_words)
        if score >= 2 or len([x for x in entries if x['author'][:4] == file_author[:4]]) == 1:
            sys.exit(0)  # match found

sys.exit(1)  # no match
" 2>/dev/null
}

# ── main sync cycle ──────────────────────────────────────────

run_sync() {
    log "🔄 Starting sync cycle..."

    # Step 1: Sync bibliography
    log "  Syncing bibliography..."
    python3 "$SCRIPT_DIR/sync_zotero.py" 2>&1 | while read -r line; do log "    $line"; done

    # Step 2: Download new PDFs
    log "  Downloading new PDFs..."
    python3 "$SCRIPT_DIR/download_zotero_pdfs.py" 2>&1 | while read -r line; do log "    $line"; done

    # Step 3: Extract text from any new PDFs
    local new_count=0
    for pdf in "$PAPERS_DIR"/*.pdf; do
        [[ -f "$pdf" ]] || continue
        local base="$(basename "$pdf" .pdf)"
        local txt="$TXT_DIR/${base}.txt"

        if [[ ! -f "$txt" ]]; then
            log "  📄 New PDF: $(basename "$pdf")"
            extract_text "$pdf" "$txt"
            if [[ -f "$txt" ]]; then
                add_index_stub "$txt"
                ((new_count++))
            fi
        fi
    done

    if (( new_count > 0 )); then
        log "✅ Added $new_count new paper(s)"
    fi

    # Step 4: Remove PDFs/TXTs no longer in bib
    local removed_count=0
    for pdf in "$PAPERS_DIR"/*.pdf; do
        [[ -f "$pdf" ]] || continue
        if ! file_matches_bib "$(basename "$pdf")"; then
            local base="$(basename "$pdf" .pdf)"
            local txt="$TXT_DIR/${base}.txt"
            log "  🗑  Removing $(basename "$pdf") (not in bib)"
            rm -f "$pdf"
            if [[ -f "$txt" ]]; then
                remove_index_entry "$txt"
                rm -f "$txt"
            fi
            ((removed_count++))
        fi
    done

    # Also check for orphaned TXTs (txt exists but no matching PDF)
    for txt in "$TXT_DIR"/*.txt; do
        [[ -f "$txt" ]] || continue
        local base="$(basename "$txt" .txt)"
        if [[ ! -f "$PAPERS_DIR/${base}.pdf" ]]; then
            log "  🗑  Removing orphaned $(basename "$txt")"
            remove_index_entry "$txt"
            rm -f "$txt"
            ((removed_count++))
        fi
    done

    if (( removed_count > 0 )); then
        log "🧹 Removed $removed_count stale file(s)"
    fi

    if (( new_count == 0 && removed_count == 0 )); then
        log "✅ Everything up to date"
    fi
}

# ── entry point ──────────────────────────────────────────────

run_sync

if $RUN_ONCE; then
    log "Done (--once mode)"
    exit 0
fi

log "👀 Watching every ${INTERVAL}s (Ctrl-C to stop)"
while true; do
    sleep "$INTERVAL"
    run_sync
done
