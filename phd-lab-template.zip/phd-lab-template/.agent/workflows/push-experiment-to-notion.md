---
description: Push local experiment markdown files to Notion (creates database, populates entries, sets summary)
---

# Push Experiment to Notion

// turbo-all

Push all `.md` files from a local `experiments/EXP_XXX/` folder to the experiment's Notion page.

## What it does

1. **Creates an inline "Lab Documents" database** inside the experiment's Notion page
2. **Creates one entry per `.md` file** with the full content parsed into Notion blocks (headings, tables, images, code, lists, etc.)
3. **Populates the main page** with `summary.md` content
4. **Images** are referenced via permanent GitHub raw URLs (the repo must be public and images committed)

## Steps

1. Identify which experiment to push (e.g. EXP_001). The experiment folder must exist at `experiments/EXP_XXX/`.

2. Dry run first to validate parsing:
```bash
python3 scripts/push_experiment_to_notion.py EXP_XXX --dry-run
```

3. If dry run looks good, push for real:
```bash
python3 scripts/push_experiment_to_notion.py EXP_XXX
```

4. Verify by opening the Notion page URL printed at the end.

## Notes

- The script **clears existing content** on the Notion page before pushing. Run with caution.
- The Notion page must already exist in the lab notebook database with the correct `EXP_xxx` property.
- Images must be committed to GitHub and the repo must be public for GitHub raw URLs to work.
- Notion API rate limits apply — the script includes delays between requests.
- Summary.md content appears both in the database AND on the main page body.
