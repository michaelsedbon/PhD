---
description: Run all syncs — bibliography + experiments — and report what's new
---

# Catch Up

Master workflow to sync everything and report what's new.
All commands run from the **workspace root** (the directory containing `scripts/`).

// turbo-all

1. First, read `.agent/MANIFEST.md` to understand the project structure.

2. Sync bibliography:
```bash
python3 scripts/sync_bibliography.py
```

3. For any new papers: read extracted text, write proper summaries in `papers_txt/INDEX.md`.

4. Sync experiments:
```bash
python3 scripts/sync_experiments.py
```

5. For any new experiments: review summaries, enrich `experiments/EXP_INDEX.md`.

6. Report a consolidated summary:
   - New papers added (with titles)
   - New experiments synced (with IDs and titles)
   - Any issues or missing data
   - Airtable data status
