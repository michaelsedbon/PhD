---
description: Create a new LaTeX paper project from the template
---

When the user asks to create a new project or paper, follow these steps:

1. **Ask the user for:**
   - Project name (e.g. "RBD Evolution Paper")
   - Target folder location (e.g. `~/Documents/PhD/New_Paper`)
   - Optionally, which Zotero library to use

2. **If the user doesn't know their Zotero library ID**, run:
   ```bash
   python3 scripts/list_zotero_libraries.py
   ```
   Show them the output and let them pick a library and (optionally) a collection.

3. **Run the init script:**
   ```bash
   ./init.sh "<target_dir>" "<Project Name>" <library_id> [collection_id]
   ```

4. **Verify** by confirming the directory was created and listing its contents.

5. **Offer next steps:**
   - Open the new project in the editor
   - Do an initial compile: `cd <target_dir> && ./compile.sh`
   - Start writing content
