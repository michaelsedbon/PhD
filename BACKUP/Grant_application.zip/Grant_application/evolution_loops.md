# Evolution Loops in the MOST Platform

This document contains block diagrams visualizing the two interlinked evolution loops described in the grant application: the **Phage Evolution Loop** (antigen) and the **Nanobody Evolution Loop** (antibody).

## 1. Phage Evolution Loop (SARS-CoV-2 RBD)
This loop focuses on continuous diversification and selection for functional receptor binding and immune escape.

```mermaid
graph TD
    subgraph "Pathogen Compartment"
        A[Phage Population<br/>RBD Variants] --> B{MP6 Mutagenesis<br/>Host E. coli}
        B -->|PACE-like infection| C[Diversified Phage<br/>Mutant Library]
        C --> D{Selection Pressure 1:<br/>ACE2 Binding}
        D -->|Functional Binders| E[ACE2-Competent Phage]
        D -->|Non-binders| F[Discard]
        
        E --> G{Selection Pressure 2:<br/>Immune Escape}
        G -->|Centrifugation| H[Supernatant:<br/>Escape Variants]
        G -->|Centrifugation| I[Pellet:<br/>Bound Phage & Bacteria]
        
        H -->|Iterative Reseeding| A
    end
```

## 2. Nanobody Evolution Loop (Synthetic Germinal Centre)
This loop emulates the B-cell maturation process in a germinal centre.

```mermaid
graph TD
    subgraph "Host Immune Compartment"
        X[Nanobody Pool<br/>VHH Scaffold] --> Y{Dark Zone:<br/>T7 Orthogonal Replisome}
        Y -->|Hypermutation| Z[Diversified Nb-Displaying Cells]
        
        Z --> W{Light Zone:<br/>Antigen Binding}
        W -->|Centrifugation| V[Pellet:<br/>Nb+ Cells & Bound Phage]
        W -->|Centrifugation| U[Supernatant:<br/>Escape Phage]
        
        V --> T[Selective Infection<br/>& CRISPR Recording]
        T --> S[Clonal Expansion]
        S -->|Feedback Migration| Y
    end
```

## Co-evolutionary Coupling
The two loops are coupled through the **Light Zone** interaction: phage variants drive nanobody selection, and neutralising nanobodies drive the emergence of viral escape mutants.

---
*Note: These diagrams represent the iterative cycle described in the Methods section of the Maimonide grant application.*
