#!/usr/bin/env python3
"""List all Zotero libraries and collections available to the configured user."""

import os
import sys
import yaml
import requests

# --- Load API key from project.yaml or env ---
project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
config_path = os.path.join(project_dir, 'project.yaml')

API_KEY = os.environ.get('ZOTERO_API_KEY')
if not API_KEY and os.path.exists(config_path):
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    API_KEY = cfg.get('zotero', {}).get('api_key', '')

if not API_KEY or API_KEY == 'YOUR_API_KEY_HERE':
    print("Error: No Zotero API key found.")
    print("Set ZOTERO_API_KEY env var or add it to project.yaml.")
    sys.exit(1)

HEADERS = {
    'Zotero-API-Key': API_KEY,
    'Zotero-API-Version': '3',
}

# --- Discover user key ID ---
resp = requests.get('https://api.zotero.org/keys/current', headers=HEADERS)
resp.raise_for_status()
key_info = resp.json()
user_id = str(key_info.get('userID', ''))

print(f"Zotero User ID: {user_id}\n")

# --- List user library collections ---
print("=" * 60)
print("YOUR PERSONAL LIBRARY  (library_type: user)")
print("=" * 60)
print(f"  Library ID : {user_id}")
print(f"  Full library (no collection filter) → collection_id: \"\"")

url = f"https://api.zotero.org/users/{user_id}/collections?limit=100"
resp = requests.get(url, headers=HEADERS)
resp.raise_for_status()
collections = resp.json()

if collections:
    print(f"\n  Collections ({len(collections)}):")
    for c in sorted(collections, key=lambda x: x['data']['name']):
        data = c['data']
        parent = f"  (parent: {data['parentCollection']})" if data.get('parentCollection') else ""
        n_items = data.get('numItems', '?')
        print(f"    • {data['name']:40s}  id: {data['key']}  items: {n_items}{parent}")
else:
    print("\n  No collections found.")

# --- List group libraries ---
url = f"https://api.zotero.org/users/{user_id}/groups?limit=100"
resp = requests.get(url, headers=HEADERS)
resp.raise_for_status()
groups = resp.json()

if groups:
    print(f"\n{'=' * 60}")
    print(f"GROUP LIBRARIES ({len(groups)})")
    print("=" * 60)
    for g in groups:
        data = g['data']
        gid = data['id']
        print(f"\n  {data['name']}")
        print(f"    Library ID : {gid}   (library_type: group)")

        curl = f"https://api.zotero.org/groups/{gid}/collections?limit=100"
        cresp = requests.get(curl, headers=HEADERS)
        cresp.raise_for_status()
        gcols = cresp.json()
        if gcols:
            print(f"    Collections ({len(gcols)}):")
            for c in sorted(gcols, key=lambda x: x['data']['name']):
                cd = c['data']
                n_items = cd.get('numItems', '?')
                print(f"      • {cd['name']:38s}  id: {cd['key']}  items: {n_items}")
        else:
            print("    No collections.")
else:
    print("\nNo group libraries found.")

print(f"\n{'=' * 60}")
print("Use the Library ID and (optionally) a collection ID when")
print("creating a new project with init.sh.")
