---
description: Sync Google Doc to formatted PDF for page count estimation
---
// turbo-all

# Sync Google Doc → PDF

This workflow fetches the latest content from a shared Google Doc, converts it to a properly formatted LaTeX file, and compiles it to PDF.

## Steps

1. Run the sync script from the grant proposal directory:
```bash
cd <grant_proposal_dir>
python3 scripts/sync_gdoc_to_pdf.py
```

This will:
- Fetch the Google Doc as plain text
- Accept all suggestions (strips comment markers like [a], [b], etc.)
- Generate a formatted `.tex` file with proper formatting:
  - Times New Roman 11pt
  - 1.5 line spacing
  - Single column, A4
  - No bibliography section (but citation numbers [1], [2]... are kept inline)
- Compile to PDF

2. Open the resulting PDF to check page count.

## Notes
- Update the Google Doc ID in the script before first use.
