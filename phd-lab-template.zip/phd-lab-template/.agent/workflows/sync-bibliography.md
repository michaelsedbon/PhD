---
description: Sync new papers from Notion bibliography, download PDFs, extract text, summarise, and update INDEX.md
---

# Sync Bibliography

// turbo-all

1. Run the bibliography sync script (from the workspace root):
```bash
python3 scripts/sync_bibliography.py
```

2. Check if any new papers were downloaded. **For each new paper you MUST:**
   a. Read the full extracted text file in `papers_txt/`
   b. Write a detailed summary entry in `papers_txt/INDEX.md` with ALL of the following fields:
      - `## <Paper Title>`
      - `**File:** <filename.txt>`
      - `**Subjects:** <comma-separated tags from Notion>`
      - `**URL:** <source URL>`
      - A **paragraph-length summary** (4-8 sentences) covering:
        - The core method / experimental approach
        - Key quantitative results or findings
        - Why it matters (relevance to the lab's research themes)
        - Connections to other papers in the index, if any
   c. Do NOT leave auto-generated stubs — every entry must have a real summary.

3. Report what was synced:
   - Number of new papers downloaded
   - Titles of new papers with one-line summaries
   - Any papers without PDF attachments (notify user so they can upload in Notion)
