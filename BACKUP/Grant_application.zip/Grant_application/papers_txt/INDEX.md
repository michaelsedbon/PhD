# Paper Index

Quick-reference index for the AI assistant. When a literature question arises,
scan the summaries below to decide which full paper(s) to load from this folder.

---

## Adachi et al. 2015
**File:** `Adachi_2015_Distinct_germinal_center_selection_at.txt`
**Citation key:** `adachi_distinct_2015`
**Title:** Distinct germinal center selection at local sites shapes memory B cell response to viral escape

Respiratory influenza infection in mice drives persistent germinal centres (GCs) in the lungs (iBALT) that harbour elevated cross-reactive memory B cells compared to splenic GCs. Local lung GCs support exaggerated B cell proliferation and clonal selection for broadly reactive repertoires, producing memory progenitors that target conserved HA epitopes across drifted virus strains. Key concepts: tissue-resident GC heterogeneity, cross-reactive memory B cell generation, somatic hypermutation accumulation, lung iBALT.

---

## Allen, Okada & Cyster 2008
**File:** `Allen_08_2_Germinal-Center_Organization_and_Cellular_Dynamics.txt`
**Citation key:** `allen_germinal-center_2007`
**Title:** Germinal-Center Organization and Cellular Dynamics

Comprehensive review of GC biology: dark zone (CXCR4⁺, proliferation, SHM) vs. light zone (CXCR5⁺, selection on FDCs, T cell help). Discusses the classical centroblast/centrocyte model and its revision based on two-photon imaging — cells in both zones are morphologically similar and proliferation occurs in both. Reviews chemokine-guided migration between zones, FDC antigen retention, and generation of long-lived plasma cells and memory B cells. **Core reference for the GC analogy used in the grant.**

---

## Badran & Liu 2015
**File:** `Badran_2015_Development_of_potent_in_vivo.txt`
**Citation key:** `badran_development_2015`
**Title:** Development of potent in vivo mutagenesis plasmids with broad mutational spectra

Describes mutagenesis plasmids (MP1–MP6) for *E. coli* in vivo mutagenesis. MP6 enhances mutation rates 322,000-fold over basal levels via arabinose-inducible expression of *dnaQ926*, *dam*, *seqA*, *ugi*, *cda1*, and *emrR*. Demonstrated antibiotic resistance evolution in <24 h and T7 RNAP promoter switching in <10 h. Applicable to chromosomes, episomes, and phage genomes. **Key technology for the dark-zone mutagenesis module in the grant.**

---

## Diercks et al. 2024
**File:** `Diercks_2024_An_Orthogonal_T7_Replisome_for.txt`
**Citation key:** `diercks_orthogonal_2024`
**Title:** An Orthogonal T7 Replisome for Continuous Hypermutation and Accelerated Evolution in *E. coli*

Introduces T7-ORACLE: an orthogonal replication system in *E. coli* based on the T7 bacteriophage replisome. The T7 DNA polymerase exclusively replicates a plasmid carrying a T7 origin, achieving mutation rates of 1.7 × 10⁻⁵ spb — 100,000-fold above the genomic rate — without compromising host fitness. Demonstrated expansion of TEM-1 β-lactamase substrate scope against monobactam and cephalosporin antibiotics in <1 week. Circular plasmid format gives high transformation efficiency (2.4 × 10¹⁰ cfu/µg). **Primary technology for the dark-zone somatic hypermutation analogue in the grant.**

---

## Glass & Riedel-Kruse 2018
**File:** `Glass_07_2_A_Synthetic_Bacterial_Cell-Cell_Adhesion.txt`
**Citation key:** `glass_synthetic_2018`
**Title:** A Synthetic Bacterial Cell-Cell Adhesion Toolbox for Programming Multicellular Morphologies and Patterns

A genetically encoded adhesion platform in *E. coli* using outer-membrane-displayed nanobodies and their cognate antigens fused to the intimin autotransporter. Three orthogonal Nb–Ag adhesin pairs (Nb1/Ag1, Nb2/Ag2, Nb3/Ag3) enable controlled cell–cell adhesion with tunable specificity and affinity. Demonstrated lattice-like self-assembly, phase separation, differential adhesion, and sequential layering. **Foundation for the light-zone nanobody display and selection module in the grant.**

---

## Miller, Wang & Liu 2020
**File:** `Miller_12_2_Phage-assisted_continuous_and_non-continuous_evolution.txt`
**Citation key:** `miller_phage-assisted_2020`
**Title:** Phage-assisted continuous and non-continuous evolution (PACE/PANCE)

Detailed protocol for PACE: M13 filamentous phage lacking *gIII* infects host *E. coli* in a continuous-flow lagoon; phage survival is linked to the activity of a protein of interest (POI) via an accessory plasmid (AP) that conditionally expresses *gIII*. Mutagenesis plasmids (MP1–MP6) diversify the evolving phage in situ. Includes negative selection (pIII-neg), stepping-stone APs, drift plasmids (DP), and PANCE (serial-dilution variant for lower stringency). >100 rounds of evolution achievable in ~2 weeks. **Methodological backbone for the phage-based selection cycle in the grant.**

---

## Pérez-Massón et al. 2024
**File:** `Pérez-Massón_2024_Studying_SARS-CoV-2_interactions_using_phage-displayed.txt`
**Citation key:** `perez-masson_studying_2024`
**Title:** Studying SARS-CoV-2 interactions using phage-displayed receptor binding domain as a model protein

Displays biologically active SARS-CoV-2 RBD (fragment 328–533) on M13 filamentous phage via pIII fusion. Mutational scanning confirmed global plasticity of the receptor binding motif, identified critical residues for ACE2 binding, and found mutations strengthening the interaction. VOC RBDs (Alpha, Beta, Delta, Omicron) were characterised for affinity differences. Vaccine-induced antibodies were evaluated for ACE2-blocking capacity against multiple RBD variants. **Validates phage display of complex eukaryotic antigens; relevant precedent for the grant's nanobody display approach.**

---

## Riechmann & Holliger 1997
**File:** `Riechmann_07_1_The_C-Terminal_Domain_of_TolA.txt`
**Citation key:** `riechmann_c-terminal_1997`
**Title:** The C-Terminal Domain of TolA Is the Coreceptor for Filamentous Phage Infection of *E. coli*

Identifies the C-terminal domain of TolA (TolA-III) as the obligatory coreceptor for M13/fd phage infection of *E. coli*. The g3p minor coat protein has three domains: g3p-D2 binds the F pilus (primary receptor); g3p-D1 binds TolA-III (coreceptor for membrane penetration). In wild-type phage, g3p-D2 masks the TolA-binding site on g3p-D1 — pilus contact releases this block, enabling a sequential two-step docking mechanism analogous to eukaryotic virus entry. **Important for understanding M13 phage infection biology and engineering phage tropism in the grant.**

---

## Sheth et al. 2017
**File:** `Sheth_2017_Multiplex_recording_of_cellular_events.txt`
**Citation key:** `sheth_multiplex_2017`
**Title:** Multiplex recording of cellular events over time on CRISPR biological tape

Introduces TRACE (Temporal Recording in Arrays by CRISPR Expansion): biological signals trigger intracellular DNA amplification (via copy-number-inducible trigger plasmids), and the amplified DNA is captured as spacers in genomic CRISPR arrays by Cas1–Cas2. Spacer identity (trigger vs. reference) and ordering encode temporal information. Demonstrated stable multi-day recording, accurate temporal reconstruction across 16 signal profiles, and multiplexed recording of three metabolites (copper, trehalose, fucose) simultaneously using barcoded CRISPR arrays. **Core technology for the lineage tracing / molecular recording module in the grant.**

---

## Zahradník et al. 2021
**File:** `Zahradník_2021_SARS-CoV-2_variant_prediction_and_antiviral.txt`
**Citation key:** `zahradnik_sars-cov-2_2021`
**Title:** SARS-CoV-2 variant prediction and antiviral drug design are enabled by RBD in vitro evolution

Used yeast surface display and iterative error-prone PCR to affinity-mature SARS-CoV-2 RBD against ACE2. Successive libraries (S1→B6) selected mutations also found in real-world VOCs (S477N, E484K, N501Y). Achieved 1,000-fold affinity increase. High-affinity variant RBD-62 inhibited infection by Alpha, Beta, and Gamma variants in vitro and reduced disease in a hamster challenge model. 2.9 Å cryo-EM structure of RBD-62:ACE2 complex resolved. Positive correlation between RBD–ACE2 binding affinity and GISAID mutation prevalence demonstrates predictive power of in vitro evolution. **Motivating example for the grant: directed evolution can anticipate viral evolution.**

---

## Corti et al. 2021
**File:** `Corti_06_2_Tackling_COVID-19_with_neutralizing_monoclonal.txt`
**Citation key:** `corti_tackling_2021`
**Title:** Tackling COVID-19 with neutralizing monoclonal antibodies

Review of neutralizing monoclonal antibodies (mAbs) against SARS-CoV-2. Discusses isolation of potent mAbs from convalescent COVID-19 patients via B cell cloning, targeting the spike protein receptor-binding domain. Covers polyclonal vs. monoclonal approaches, antibody cocktail strategies, and the challenge of viral escape mutations reducing mAb efficacy. **Cited in the introduction for the claim that antibodies are isolated from convalescent or immunised donors.**

---

## Cox et al. 2021
**File:** `Cox_2020_Therapeutically_administered_ribonucleoside_analogue_MK-4482_EIDD-2801.txt`
**Citation key:** `cox_therapeutically_2020`
**Title:** Therapeutically administered ribonucleoside analogue MK-4482/EIDD-2801 blocks SARS-CoV-2 transmission in ferrets

Demonstrates that the antiviral ribonucleoside analogue MK-4482/EIDD-2801 (molnupiravir) blocks SARS-CoV-2 transmission in a ferret model. ⚠️ **Note:** This paper is about a small-molecule antiviral drug, NOT about monoclonal antibody escape. It was used as a placeholder citation in the introduction and should be replaced with a more appropriate reference on antibody escape.

---

## Frei et al. 2015
**File:** `Frei_11_2_Comprehensive_mapping_of_functional_epitopes.txt`
**Citation key:** `frei_comprehensive_2015`
**Title:** Comprehensive mapping of functional epitopes on dengue virus glycoprotein E

*(Auto-generated stub — update summary after reviewing the paper.)*

---

## Markov et al. 2023
**File:** `Markov_06_2_The_evolution_of_SARS-CoV-2.txt`
**Citation key:** `markov_evolution_2023`
**Title:** The evolution of SARS-CoV-2

Comprehensive review of SARS-CoV-2 evolution: mutation rates, antigenic drift, immune escape, and VOC origins. Discusses how immune escape mutations (E484K, N501Y) drive variant emergence and reduce neutralization by sera from vaccinated/infected individuals. Future scenarios include seasonal circulation patterns and continued antigenic evolution. **Cited in the introduction for the claim that the virus circulates seasonally with new antigenic variants each year.**

---

## Sui et al. 2009
**File:** `Sui_03_2_Structural_and_functional_bases_for.txt`
**Citation key:** `sui_structural_2009`
**Title:** Structural and functional bases for broad-spectrum neutralization of avian and human influenza A viruses

*(Auto-generated stub — update summary after reviewing the paper.)*

