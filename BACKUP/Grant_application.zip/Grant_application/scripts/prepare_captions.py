#!/usr/bin/env python3
import re
import os
import subprocess
import yaml
import sys

def extract_captions(tex_content):
    """
    Extracts all text inside \captionof{figure}{...}.
    Handles nested braces to ensure the full caption is captured.
    """
    captions = []
    # Find all occurrences of \captionof{figure}{
    pattern = re.compile(r'\\captionof\{figure\}\s*\{')
    for match in pattern.finditer(tex_content):
        start_index = match.end()
        # Find balanced closing brace
        brace_level = 1
        current_index = start_index
        while brace_level > 0 and current_index < len(tex_content):
            char = tex_content[current_index]
            if char == '{':
                brace_level += 1
            elif char == '}':
                brace_level -= 1
            current_index += 1
        
        if brace_level == 0:
            caption_text = tex_content[start_index:current_index-1].strip()
            captions.append(caption_text)
    
    return captions

def main():
    # Load project config
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(script_dir)
    
    with open(os.path.join(project_dir, "project.yaml"), "r") as f:
        config = yaml.safe_load(f)
    
    main_tex_path = os.path.join(project_dir, config["project"]["main_tex"])
    
    with open(main_tex_path, "r") as f:
        tex_content = f.read()
    
    captions = extract_captions(tex_content)
    
    if not captions:
        print("No captions found to extract.")
        return

    # Prepare standalone LaTeX content
    # We use a similar preamble to the main document for styling consistency
    standalone_tex = r"""\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{microtype}
\usepackage{lmodern}
\usepackage[dvipsnames]{xcolor}
\usepackage{caption}

\begin{document}
\pagestyle{empty}
"""
    for i, cap in enumerate(captions):
        standalone_tex += f"\\noindent\\textbf{{Figure {i+1}:}} {cap}\n\n\\vspace{{1em}}\n"
    
    standalone_tex += "\\end{document}\n"

    # Write temporary tex file
    tmp_tex_path = os.path.join(project_dir, "Figures", "caption.tex")
    with open(tmp_tex_path, "w") as f:
        f.write(standalone_tex)

    # Compile using pdflatex
    try:
        print(f"Compiling standalone captions to Figures/caption.pdf...")
        # Run pdflatex in the Figures directory
        subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "caption.tex"],
            cwd=os.path.join(project_dir, "Figures"),
            check=True,
            capture_output=True
        )
        print("✓ Successfully generated Figures/caption.pdf")
    except subprocess.CalledProcessError as e:
        print(f"⚠ Error compiling caption.pdf:\n{e.stderr.decode()}", file=sys.stderr)
        sys.exit(1)
    finally:
        # Cleanup temporary files
        fig_dir = os.path.join(project_dir, "Figures")
        for ext in [".tex", ".aux", ".log", ".out"]:
            p = os.path.join(fig_dir, "caption" + ext)
            if os.path.exists(p):
                os.remove(p)

if __name__ == "__main__":
    main()
