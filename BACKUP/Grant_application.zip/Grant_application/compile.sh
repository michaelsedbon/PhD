#!/bin/zsh
# Ensure TeX binaries and Python are in PATH
eval "$(/usr/libexec/path_helper)"

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
TEX_FILE=$(python3 -c "import yaml; print(yaml.safe_load(open('$PROJECT_DIR/project.yaml'))['project']['main_tex'])")
BUILD_DIR=$(python3 -c "import yaml; print(yaml.safe_load(open('$PROJECT_DIR/project.yaml'))['project'].get('build_dir', 'build'))")
BASE="${TEX_FILE%.tex}"

# Handle clean command
if [[ "$1" == "clean" ]]; then
    echo "--- Cleaning build artifacts ---"
    latexmk -C -outdir="$BUILD_DIR" "$TEX_FILE"
    rm -f ${BASE}.{aux,bbl,bcf,blg,fdb_latexmk,fls,log,run.xml,synctex.gz,bbl-SAVE-ERROR} 2>/dev/null
    exit 0
fi

# Sync papers (bib + PDFs + text extraction + cleanup)
echo "--- Syncing Papers from Zotero ---"
"$PROJECT_DIR/scripts/watch_zotero.sh" --once

# Extract figure captions and compile Figures/caption.pdf
echo "\n--- Preparing Figure Captions ---"
python3 "$PROJECT_DIR/scripts/prepare_captions.py"

# Compile using latexmk (all output goes to build/)
echo "\n--- Compiling LaTeX Document ---"
latexmk -synctex=1 -interaction=nonstopmode -file-line-error -pdf \
    -outdir="$BUILD_DIR" -auxdir="$BUILD_DIR" "$TEX_FILE"

# Convert to Word document
echo "\n--- Converting to Word Document ---"
BIB_FILES=($(grep '\\addbibresource{' "$TEX_FILE" | sed 's/.*\\addbibresource{\(.*\)}/\1/'))
BIB_ARGS=()
for bib in "${BIB_FILES[@]}"; do
  [[ -f "$bib" ]] && BIB_ARGS+=("--bibliography=$bib")
done
pandoc "$TEX_FILE" -f latex+raw_tex -o "$BUILD_DIR/${BASE}.docx" --citeproc --csl="$PROJECT_DIR/scripts/numeric.csl" --lua-filter="$PROJECT_DIR/scripts/color-filter.lua" "${BIB_ARGS[@]}" \
  || echo "Warning: Word document conversion failed"

# Clean any stray artifacts that latexmk leaves in the root
rm -f ${BASE}.{aux,bbl,bcf,blg,fdb_latexmk,fls,log,run.xml,synctex.gz,bbl-SAVE-ERROR} 2>/dev/null
