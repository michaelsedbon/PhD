---
description: Interactive first-time setup — walk the user through configuring their lab workspace step by step
---

# First-Time Setup (Interactive)

This workflow is conversational. Guide the user through each step, ask questions one at a time, wait for answers, and fill in config files for them.

## 0. Welcome

Start with a warm welcome:

> 👋 Welcome to your AI Lab Workspace! I'm your lab assistant and I'll help you get everything set up. This will take about 15 minutes.
>
> We need to connect three services: **Notion** (for your lab notebook and bibliography), **Zotero** (for reference management), and optionally **Airtable** (for lab inventory).
>
> Let's start! Do you already have accounts on these services, or do we need to create them?

## 1. Notion Setup

### 1a. Create the Integration

Ask:
> First, let's set up Notion. Go to [notion.so/my-integrations](https://www.notion.so/my-integrations) and click **"+ New integration"**.
>
> - Give it a name like "Lab Assistant"
> - Select your workspace
> - Click Submit
>
> You'll see an **"Internal Integration Secret"** (starts with `ntn_` or `secret_`). Paste it here and I'll save it for you.

Wait for the user to paste their token.

### 1b. Lab Notebook Database

Ask:
> Now let's set up your **Lab Notebook** database in Notion. You have two options:
>
> 1. **I already have a database** — share the link and I'll extract the ID
> 2. **I need to create one** — I'll tell you exactly what columns to add
>
> Which one?

If they need to create one, guide them:
> Create a new **full-page database** in Notion and add these columns:
>
> | Column Name | Type |
> |---|---|
> | Name | Title (already there by default) |
> | Exp Number | Select |
> | Start Date | Date |
>
> Once created, **share the database link** with me (just paste the URL).

Extract the 32-char hex database ID from the URL they paste.

Then remind them:
> One more thing — click the **"..."** menu on your database → **"Connections"** → add your "Lab Assistant" integration. This gives me permission to read and write.

### 1c. Bibliography Database

Same flow — ask:
> Now let's do the same for your **Bibliography** database. This is where your papers and reading list will live.
>
> Create another full-page database with these columns:
>
> | Column Name | Type |
> |---|---|
> | Paper name | Title |
> | Subject | Multi-select |
> | URL | URL |
> | Files & media | Files |
> | Note | Rich text |
>
> Share the link when ready, and don't forget to connect the integration!

Extract the database ID.

## 2. Zotero Setup

Ask:
> Now let's set up **Zotero** for reference management. Do you already have a Zotero account?

If no:
> Go to [zotero.org/user/register](https://www.zotero.org/user/register) and create a free account. I also recommend downloading the desktop app from [zotero.org/download](https://www.zotero.org/download/).

Then:
> Now go to [zotero.org/settings/keys](https://www.zotero.org/settings/keys) to create an API key:
>
> 1. Click **"Create new private key"**
> 2. Name it "Lab Assistant"
> 3. Turn ON **"Allow library access"** and **"Allow write access"**
> 4. Click **Save Key**
>
> Two things to copy:
> - Your **API key** (shown after saving)
> - Your **userID** (shown at the top of the page — this is your library ID)
>
> Paste both here!

Wait for the key and userID.

Optional:
> Would you like me to save papers I find into a specific Zotero collection? If so, create a collection called "AI Agent" in your Zotero library and tell me its name (I'll find the ID).
>
> Or we can skip this for now — you can always set it up later.

## 3. Airtable Setup (Optional)

Ask:
> **Airtable** is used for tracking lab inventory (reagents, labware). This is optional.
>
> Do you want to set up Airtable now, or skip it?

If yes, guide them through:
> 1. Go to [airtable.com](https://airtable.com/) — create a free account if needed
> 2. Create a new **base** (think of it as a database)
> 3. Create two tables: **Reagents** and **Labware**
> 4. For your **Base ID**: open the base, and the URL will have `appXXXXXXXX` — that's it
> 5. For your **API token**: go to [airtable.com/create/tokens](https://airtable.com/create/tokens), create a token with `data.records:read` and `data.records:write` scopes, and give it access to your base
>
> Share the Base ID and token with me!

## 4. Save Configuration

Once you have all the credentials, write them to `config.yaml`:

```python
import yaml

config = {
    'notion': {
        'token': '<USER_TOKEN>',
        'lab_notebook_db': '<USER_LAB_DB_ID>',
        'bibliography_db': '<USER_BIB_DB_ID>',
    },
    'airtable': {
        'token': '<USER_AIRTABLE_TOKEN or empty>',
        'base_id': '<USER_BASE_ID or empty>',
    },
    'zotero': {
        'api_key': '<USER_ZOTERO_KEY>',
        'library_id': '<USER_LIBRARY_ID>',
        'library_type': 'user',
        'agent_collection_id': '<USER_COLLECTION_ID or empty>',
    },
}

with open('config.yaml', 'w') as f:
    yaml.dump(config, f, default_flow_style=False)
```

Tell the user:
> ✅ I've saved your credentials to `config.yaml`. This file is gitignored so your keys stay private.

## 5. Install Dependencies

Ask:
> Let's install the Python packages I need. I'll run this for you:
>
> ```bash
> pip3 install requests pyyaml pymupdf
> ```
>
> Shall I go ahead?

// turbo
```bash
pip3 install requests pyyaml pymupdf
```

## 6. Verify

Test the connection:

// turbo
```bash
python3 scripts/notion_client.py --test
```

Report the result:
> ✅ Connected to Notion! I can see your databases:
> - Lab Notebook: X entries
> - Bibliography: Y entries
>
> (or explain what went wrong and how to fix it)

## 7. Quick Tour

After setup succeeds, give a quick tour:

> 🎉 **You're all set!** Here's what you can do now:
>
> | Command | What it does |
> |---------|-------------|
> | `/catch-up` | Sync everything and get a summary |
> | `/sync-bibliography` | Pull new papers from Notion |
> | `/sync-experiments` | Pull new experiments from Notion |
> | `/update-experiment` | Log findings to an experiment |
> | `/new-grant-project` | Start a new LaTeX grant proposal |
>
> You can also just ask me things like:
> - *"Find papers about [topic]"*
> - *"What does [paper] say about [question]?"*
> - *"Summarise experiment EXP_001"*
>
> Want me to run a `/catch-up` now to sync your data?

## 8. GitHub Setup (Optional)

If the user wants to push experiments to Notion with images, ask:
> One more optional thing: if you want experiment images to show up in Notion pages, you'll need a public GitHub repo. Shall I help you set that up?

If yes:
- Help them create a repo
- Update `GITHUB_RAW_BASE` in `scripts/push_experiment_to_notion.py` with their username/repo
