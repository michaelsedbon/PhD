# Agent Paper Index

Papers downloaded and verified by the AI assistant during conversations.
Separate from the user's `papers/` collection.

---

<!-- Entries are added automatically when the AI assistant verifies paper claims. -->
<!-- Format:
## <Paper Title>
- **Authors:** ...
- **Year:** ...
- **DOI:** ...
- **Downloaded:** YYYY-MM-DD
- **Cited in context of:** <discussion topic>
- **Key finding verified:** <specific verified claim>
- **File:** `<filename.txt>`
-->
