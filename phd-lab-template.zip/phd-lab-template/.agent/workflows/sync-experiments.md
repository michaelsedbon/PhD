---
description: Sync new experiments from Notion lab notebook, fetch content, update EXP_INDEX.md
---

# Sync Experiments

// turbo-all

1. Run the experiment sync script (from the workspace root):
```bash
python3 scripts/sync_experiments.py
```

2. Check if any new experiments were synced. If yes, for each new experiment:
   a. Read the generated `summary.md` in `experiments/EXP_XXX/`
   b. Enrich the summary with context if needed
   c. Update the corresponding entry in `experiments/EXP_INDEX.md` — replace the auto-generated stub with a real summary

3. If Airtable data was fetched, review the JSON files and note any key data points in the summary.

4. Report what was synced:
   - Number of new experiments found
   - Experiment IDs and titles
   - Any experiments with Airtable data
