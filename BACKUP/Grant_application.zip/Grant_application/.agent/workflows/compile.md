---
description: Recompile the LaTeX document and update the PDF.
---

To recompile the document:

// turbo
```bash
./compile.sh
```

This will:
1. Read the main TeX filename from `project.yaml`
2. Sync the bibliography from Zotero via `scripts/sync_zotero.py`
3. Run `latexmk` with output directed to the `build/` directory
4. Convert the TeX source to a Word document (`.docx`) via `pandoc`

The compiled outputs will be at `build/MOST_Maimonide.pdf` and `build/MOST_Maimonide.docx`.

To clean all build artifacts:

```bash
./compile.sh clean
```
