# Lab Connections Cheat Sheet

Quick links to all the external platforms used in this lab.

## 📝 Notion Dashboard
- **[Lab Notebook](https://www.notion.so/YOUR_LAB_NOTEBOOK_DB_ID)** — Active experiments and protocols.
- **[Bibliography](https://www.notion.so/YOUR_BIBLIOGRAPHY_DB_ID)** — Research papers and reading list.
- **[Notion Integrations](https://www.notion.so/my-integrations)** — Manage the Lab Assistant API token.

## 📊 Airtable Dashboard
- **[Inventory Base](https://airtable.com/YOUR_BASE_ID)** — Reagents, Labware, and Strains.
- **[Airtable Personal Access Tokens](https://airtable.com/create/tokens)** — Manage API access tokens.

## 📚 Zotero
- **[Zotero Web Library](https://www.zotero.org/YOUR_USERNAME/library)** — Your reference library.
- **[Zotero API Keys](https://www.zotero.org/settings/keys)** — Manage API keys.

## 🛠 Lab Assistant Command Summary
- `python3 scripts/sync_experiments.py` — Sync Notion experiments.
- `python3 scripts/sync_bibliography.py` — Sync Notion bibliography.
- `python3 scripts/fetch_airtable.py --test` — Test Airtable connection.
- `python3 scripts/explore_paper_network.py --doi "DOI"` — Explore citation network.
