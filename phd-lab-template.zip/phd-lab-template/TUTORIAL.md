# 📖 Tutorial — How to Use Your AI Lab Workspace

This tutorial explains everything your workspace can do and walks you through real-world examples. It's written for someone who has already completed [GETTING_STARTED.md](GETTING_STARTED.md).

---

## Table of Contents

1. [How This Workspace Works](#1-how-this-workspace-works)
2. [Managing Your Bibliography](#2-managing-your-bibliography)
3. [Working With Experiments](#3-working-with-experiments)
4. [Exploring Paper Networks](#4-exploring-paper-networks)
5. [Verifying Paper Claims](#5-verifying-paper-claims)
6. [Writing Grant Proposals](#6-writing-grant-proposals)
7. [Building Lab Web Apps](#7-building-lab-web-apps)
8. [Daily Workflow Patterns](#8-daily-workflow-patterns)
9. [How the AI Assistant Uses the Workspace](#9-how-the-ai-assistant-uses-the-workspace)
10. [Tips & Best Practices](#10-tips--best-practices)
11. [Troubleshooting](#11-troubleshooting)
12. [Customising the Workspace](#12-customising-the-workspace)

---

## 1. How This Workspace Works

Your lab workspace is a folder on your computer that connects to three cloud services:

```
┌─────────┐     ┌──────────────────────────────────┐     ┌──────────┐
│  Notion  │◄──►│    Your Lab Workspace (local)    │◄──►│  Zotero  │
│  (cloud) │     │  papers/ experiments/ scripts/   │     │  (cloud) │
└─────────┘     └──────────────────────────────────┘     └──────────┘
                              ▲
                              │
                         ┌────┴─────┐
                         │ Airtable │
                         │  (cloud) │
                         └──────────┘
```

- **Notion** stores your lab notebook (experiments) and bibliography (papers)
- **Zotero** manages your reference library and bibliography files
- **Airtable** tracks your reagents and labware inventory (optional)
- **Your local folder** has the full-text papers, experiment reports, and scripts

The **AI assistant** can read and write all of these through Python scripts and slash commands.

### The .agent/ Folder

The `.agent/` folder is the AI assistant's brain inside your workspace:

```
.agent/
├── MANIFEST.md            ← The AI reads this first in every conversation.
│                             Think of it as "project memory" — it explains
│                             the folder structure, database schemas, and rules.
│
├── workflows/             ← Slash commands. When you type /sync-bibliography
│   ├── sync-bibliography.md   the AI follows the steps in this file.
│   ├── catch-up.md
│   └── ...
│
└── skills/                ← More complex behaviours the AI uses automatically.
    ├── explore-paper-network/   Finds related papers via citation networks.
    ├── fetch-papers/            Downloads PDFs from Sci-Hub.
    └── verify-paper-claims/     Verifies claims before citing papers.
```

> 💡 **You don't need to read these files yourself.** The AI reads them. But knowing they exist helps you understand *why* the AI behaves the way it does.

---

## 2. Managing Your Bibliography

### Adding Papers to Notion

1. Go to your **Bibliography database** in Notion
2. Add a new entry:
   - **Paper name:** Full title of the paper
   - **URL:** The DOI link (e.g. `https://doi.org/10.1038/s41586-023-06600-9`)
   - **Subject:** Add tags (e.g. "CRISPR", "Directed Evolution")
   - **Files & media:** Upload the PDF if you have it
3. The AI will pick it up on the next sync

### Syncing Your Bibliography

Tell the AI:

> **You:** `/sync-bibliography`

The AI will:
1. Query your Notion bibliography database
2. Download any new PDFs (from Notion attachments)
3. Extract the text from each PDF
4. Write a detailed summary in `papers_txt/INDEX.md`
5. Report what was synced

After syncing, you'll find:
```
papers/
├── paper_one_title.pdf
├── paper_two_title.pdf
└── ...

papers_txt/
├── INDEX.md              ← Summaries for AI lookup
├── paper_one_title.txt
├── paper_two_title.txt
└── ...
```

### Downloading Papers from Sci-Hub

If your Notion entries have DOI links but no PDF:

> **You:** Can you download the papers that are missing PDFs?

The AI uses `scripts/fetch_papers.py` to try Sci-Hub mirrors. You can also run it manually:

```bash
# See what would be downloaded
python3 scripts/fetch_papers.py --dry-run

# Download missing papers
python3 scripts/fetch_papers.py

# Download only papers with "CRISPR" in the title
python3 scripts/fetch_papers.py --filter "CRISPR"
```

### Asking Questions About Your Papers

Once papers are synced, the AI can answer questions using the full text:

> **You:** What did the Smith 2023 paper say about the efficiency of prime editing?

The AI will:
1. Check `papers_txt/INDEX.md` to find the paper
2. Read the full text file
3. Answer with quotes and specific details from the paper

---

## 3. Working With Experiments

### Creating an Experiment in Notion

1. Go to your **Lab Notebook** database in Notion
2. Add a new entry:
   - **Name:** Title of the experiment
   - **Exp Number:** `EXP_001` (or next available)
   - **Start Date:** Today's date

### Syncing Experiments

> **You:** `/sync-experiments`

The AI will:
1. Query your Notion lab notebook
2. Create `experiments/EXP_001/` folders for new entries
3. Generate `summary.md` with the Notion page content
4. Update `experiments/EXP_INDEX.md` with summaries

### Updating an Experiment

When you have new data, observations, or analysis:

> **You:** `/update-experiment`
> **AI:** Which experiment?
> **You:** EXP_001 — I ran the gel electrophoresis and got these results: [describe results]

The AI will:
1. Append your findings to `experiments/EXP_001/summary.md` with a dated heading
2. Generate plots if you provide data
3. Update `experiments/EXP_INDEX.md`
4. Push the update to the Notion page

### Experiment Folder Structure

Each experiment follows this layout:

```
experiments/EXP_001/
├── summary.md          ← Main document (always start here)
│                         Has a Document Index table at the top
├── LOG.md              ← Chronological activity log
├── LITERATURE.md       ← Related paper reviews (optional)
├── data/               ← Figures, CSVs, plots
│   ├── gel_photo.png
│   └── growth_curve.csv
└── scripts/            ← Analysis scripts
    └── analyse_growth.py
```

**Rules:**
- Markdown files (`.md`) live at the root of the experiment folder
- Data files go in `data/`
- Scripts go in `scripts/`
- The AI keeps the Document Index table at the top of `summary.md` up to date

### Pushing Experiments to Notion

To push all your local experiment documents to the Notion page:

> **You:** `/push-experiment-to-notion`
> **AI:** Which experiment?
> **You:** EXP_001

This creates an inline database on the Notion page with all your markdown files, fully formatted.

---

## 4. Exploring Paper Networks

When you want to find related literature, the AI can explore citation networks using the Semantic Scholar API (free, no key required):

> **You:** Can you find papers related to this DOI: 10.1038/ncomms9101?

The AI uses `scripts/explore_paper_network.py` to:
1. Find papers that **cite** this paper
2. Find papers that this paper **references**
3. Get ML-based similar paper recommendations
4. Rank results by citation count and relevance

### Multiple Seed Papers

For the best results, provide multiple seed papers:

> **You:** Find papers at the intersection of directed evolution and machine learning. Start from these DOIs: 10.1038/s41586-019-1192-5 and 10.1126/science.aad8711

The AI will find papers appearing in *multiple* citation networks — these are the most relevant.

### Filtering

> **You:** Find highly-cited papers from 2020 onwards about E. coli genome engineering, starting from [DOI]

The AI filters by keyword, citation count, and year.

### Running Manually

```bash
# Single paper
python3 scripts/explore_paper_network.py --doi "10.1038/ncomms9101"

# Multiple papers + keyword filter
python3 scripts/explore_paper_network.py \
    --doi "10.1038/ncomms9101" \
    --doi "10.1126/science.aad8711" \
    --keyword "genome" --min-citations 50

# Save as markdown report
python3 scripts/explore_paper_network.py \
    --doi "10.1038/ncomms9101" \
    --output agent_papers_txt/network_report.md
```

---

## 5. Verifying Paper Claims

**This is one of the most powerful features.** The AI is configured to *never cite a paper without reading it first*.

When the AI recommends or cites a paper, it automatically:

1. Checks if it already has the paper text
2. Downloads the PDF via Sci-Hub (if not already downloaded)
3. Extracts the text
4. Reads the relevant sections
5. Verifies the claim is actually supported
6. Updates `agent_papers_txt/INDEX.md` with the verified citation
7. Only then presents the citation with a note that it was verified

### What This Looks Like

> **You:** What papers describe using CRISPR-Cas9 for large-scale genome editing in E. coli?
>
> **AI:** I found and verified two relevant papers:
>
> 1. **Wang et al., 2023** — I downloaded and checked this paper. It describes a method for multiplexed genome editing using... [direct quote from paper]
>
> 2. **Smith & Jones, 2022** — Verified. The authors demonstrate... [specific finding]
>
> ⚠️ I also found Li et al. 2021 but couldn't download the PDF. I cannot verify the specific claims.

The verified papers and their metadata end up in `agent_papers_txt/INDEX.md` for future reference.

---

## 6. Writing Grant Proposals

The workspace includes a complete LaTeX grant proposal system.

### Creating a New Grant Proposal

> **You:** `/new-grant-project`
> **AI:** What's the project name and where should I create it?
> **You:** "Neural Network Evolution" in ~/Documents/PhD/NN_Evolution_Grant

The AI runs `./grant_template/init.sh` which creates:

```
NN_Evolution_Grant/
├── .agent/
│   ├── MANIFEST.md          ← AI memory for this project
│   └── workflows/
├── Neural_Network_Evolution.tex   ← Main document
├── neural_network_evolution.bib   ← Auto-synced from Zotero
├── manual_additions.bib           ← Manual references
├── project.yaml                   ← Project configuration
├── compile.sh                     ← Build script
├── Figures/                       ← Images
├── papers/                        ← Reference PDFs
├── papers_txt/                    ← Extracted text
└── scripts/                       ← Zotero sync scripts
```

### Editing a Grant Proposal

The AI follows a **diff-first** workflow for grant documents:

> **You:** Add a paragraph about machine learning in the introduction
>
> **AI:** Here's the proposed change:
> ```diff
> +Machine learning has emerged as a powerful tool for...
> ```
> Shall I apply this?
>
> **You:** Yes
>
> **AI:** Applied and recompiling... ✅ Build succeeded.

Red text (`\textcolor{BrickRed}{...}`) is used to mark speculative ideas or unverified claims.

### Compiling

> **You:** `/compile-grant`

Or manually:
```bash
cd ~/Documents/PhD/NN_Evolution_Grant
./compile.sh          # Sync Zotero → compile PDF + DOCX
./compile.sh clean    # Remove build artifacts
```

### Managing the Bibliography

The bibliography is synced from Zotero:

- `neural_network_evolution.bib` — auto-generated, **do not edit**
- `manual_additions.bib` — for references not in Zotero

The AI can add papers to your Zotero library and sync the bibliography.

---

## 7. Building Lab Web Apps

The workspace supports building web applications for lab tools:

> **You:** `/create-app`
> **AI:** What should the app do?
> **You:** A growth curve plotter that takes CSV files and generates interactive plots

The AI scaffolds a Next.js + FastAPI application under `applications/`.

### App Structure

```
applications/growth-plotter/
├── README.md           ← What it does, how to run
├── CATCHUP.md          ← Living changelog
├── server/             ← Python FastAPI backend
│   ├── main.py
│   └── requirements.txt
└── dashboard/          ← Next.js frontend
    ├── src/
    └── package.json
```

### Running an App

```bash
# Backend
cd applications/growth-plotter/server
python3 -m uvicorn main:app --port 8002

# Frontend
cd applications/growth-plotter/dashboard
npm run dev -- -p 3003
```

---

## 8. Daily Workflow Patterns

### Morning Catch-Up

Start your day by asking the AI to sync everything:

> **You:** `/catch-up`

This runs bibliography + experiment syncs and reports:
- New papers added to Notion
- New experiments created
- Any issues to address

### During the Day

| Task | What to say |
|------|------------|
| Log experiment results | `/update-experiment` → describe what you did |
| Search for papers | "Find papers about [topic]" |
| Check a specific paper | "What does [paper title] say about [topic]?" |
| Download missing PDFs | `/sync-bibliography` |
| Start a review | "Write a literature review on [topic] using my papers" |

### Before a Meeting

> **You:** Summarise the current status of EXP_003

The AI reads the experiment summary and gives you a concise overview.

### Writing a Paper or Grant

> **You:** `/new-grant-project`

Then work with the AI to write, edit, and refine your document. It will:
- Propose all changes as diffs
- Verify citations before using them
- Compile after every edit
- Mark uncertain content in red

---

## 9. How the AI Assistant Uses the Workspace

Understanding this helps you get the most out of the system.

### The MANIFEST.md

Every conversation, the AI reads `.agent/MANIFEST.md` first. This tells it:
- What type of project this is
- Where files are located
- How databases are structured
- What rules to follow (e.g. never cite without verifying)

**Editing tip:** If you want the AI to behave differently, edit the MANIFEST. For example, if you add a new database schema, add it here.

### Workflows (slash commands)

Files in `.agent/workflows/` define what happens when you use a slash command. Each file is a step-by-step recipe.

**Want a new workflow?** Create a `.md` file:

```markdown
---
description: Short description of what this workflow does
---

# My Custom Workflow

1. Step one...
2. Step two...
```

The slash command name comes from the filename (e.g. `my-workflow.md` → `/my-workflow`).

**Turbo mode:** Add `// turbo-all` to a workflow to let commands run without manual approval:

```markdown
// turbo-all

1. Run the sync:
\```bash
python3 scripts/my_script.py
\```
```

### Skills

Files in `.agent/skills/` describe complex behaviours the AI uses *automatically* when appropriate. Unlike workflows (invoked by you), skills are triggered by the AI itself:

- **verify-paper-claims** — Used any time the AI is about to cite a paper
- **explore-paper-network** — Used when you ask about related papers
- **fetch-papers** — Used when papers need downloading

### Index Files

The AI relies on index files to quickly understand your data:

| Index | Purpose |
|-------|---------|
| `papers_txt/INDEX.md` | Your paper summaries — the AI reads this first |
| `agent_papers_txt/INDEX.md` | Papers the AI downloaded and verified |
| `experiments/EXP_INDEX.md` | Experiment summaries |

**Keep indexes up to date.** The AI updates them automatically via workflows, but if you add files manually, make sure to update the corresponding index.

---

## 10. Tips & Best Practices

### 📌 Use DOIs When Possible

When adding papers to Notion, always include the DOI link in the URL field. This enables:
- Automatic PDF downloading
- Citation network exploration
- Proper Zotero integration

### 📌 Structured Experiment Names

Use a consistent naming scheme: `EXP_001`, `EXP_002`, etc. The scripts depend on this pattern.

### 📌 Let the AI Generate Plots

Instead of making plots yourself, describe the data:

> **You:** I measured OD600 at these timepoints: [paste CSV data]. Plot the growth curve.

The AI generates a matplotlib plot and saves it to the experiment's `data/` folder.

### 📌 Use the AI for Literature Reviews

> **You:** Search for papers about [topic], download the top 5, and write a literature review

The AI will:
1. Search via Semantic Scholar
2. Download from Sci-Hub
3. Read each paper
4. Write a structured review with verified citations

### 📌 Back Up Your Config

Since `config.yaml` is gitignored, keep a backup somewhere safe (like your password manager). If you lose it, you'll need to regenerate all the API keys.

### 📌 The AI Always Has Your Back

If the AI doesn't know something about your workspace, it will check the MANIFEST and index files before answering. If it can't find information, it will say so rather than guessing.

---

## 11. Troubleshooting

### "Could not validate credentials"

Your Notion token is wrong or expired.
1. Check `config.yaml` → `notion.token`
2. Go to [notion.so/my-integrations](https://www.notion.so/my-integrations) and verify the token
3. Make sure the integration is still connected to your databases

### "Could not find database"

The database ID in `config.yaml` is incorrect.
1. Open the database in Notion as a full page
2. Copy the 32-character ID from the URL
3. Update `config.yaml`

### "No papers downloaded"

Sci-Hub mirrors may be down.
```bash
python3 scripts/fetch_papers.py --check-mirrors
```
If all mirrors fail, try again later or download PDFs manually.

### "ModuleNotFoundError: No module named 'fitz'"

```bash
pip3 install pymupdf
```

### papers_txt/ files are empty

The PDF extraction failed. Try:
```bash
pip3 install pymupdf  # Make sure it's installed
python3 scripts/pdf_to_text.py papers/<filename>.pdf papers_txt/<filename>.txt
```

### "latexmk: command not found"

LaTeX is not installed:
```bash
brew install --cask mactex
```
Restart your terminal after installation.

### The AI seems confused about the project

Ask it to re-read the MANIFEST:

> **You:** Please re-read .agent/MANIFEST.md and papers_txt/INDEX.md

---

## 12. Customising the Workspace

### Adding a New Notion Database

1. Create the database in Notion
2. Add the schema to `.agent/MANIFEST.md`
3. Connect the integration to the new database
4. Add the database ID to `config.yaml`

### Creating a Custom Workflow

1. Create `.agent/workflows/my-workflow.md`:
   ```markdown
   ---
   description: What this workflow does
   ---
   
   1. Step one
   2. Step two
   ```
2. Use it: `/my-workflow`

### Adding a New Skill

1. Create `.agent/skills/my-skill/SKILL.md`:
   ```markdown
   ---
   name: my-skill
   description: When and how to use this skill
   ---
   
   ## When to use
   - Describe the trigger conditions
   
   ## Procedure
   1. Step one
   2. Step two
   ```
2. Reference it in `.agent/MANIFEST.md` so the AI knows about it

### Changing the Experiment Schema

1. Update your Notion database properties
2. Update the schema table in `.agent/MANIFEST.md`
3. You may need to update `scripts/sync_experiments.py` if you added new property types

### Adding More Integrations

The workspace is designed to be extensible. Common additions:
- **Google Scholar** alerts
- **Slack/Discord** notifications
- **GitHub Actions** for automated syncing
- **Additional Airtable tables** for protocols, cell lines, etc.

Just create new scripts in `scripts/` and workflows in `.agent/workflows/`.

---

*This tutorial was written to be as complete as possible. If something isn't covered here, ask your AI assistant — it knows the workspace inside out.* 🔬
