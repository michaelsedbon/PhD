#!/bin/zsh
# ============================================================
# init.sh — Scaffold a new LaTeX paper project
# ============================================================
# Usage:
#   ./init.sh <target_dir> "<Project Name>" [library_id] [collection_id]
#
# Examples:
#   ./init.sh ~/Documents/PhD/New_Paper "My New Paper"
#   ./init.sh ~/Documents/PhD/New_Paper "My Paper" 8723725
#   ./init.sh ~/Documents/PhD/New_Paper "My Paper" 8723725 ABC123
#
# To list available Zotero libraries first:
#   python3 scripts/list_zotero_libraries.py
# ============================================================

set -euo pipefail

TEMPLATE_DIR="$(cd "$(dirname "$0")" && pwd)"

# ---- Parse arguments ----
if [[ $# -lt 2 ]]; then
    echo "Usage: $0 <target_dir> \"<Project Name>\" [library_id] [collection_id]"
    echo ""
    echo "  target_dir     — where to create the new project"
    echo "  Project Name   — human-readable name (used in title and config)"
    echo "  library_id     — Zotero library ID (optional, prompted if omitted)"
    echo "  collection_id  — Zotero collection ID (optional, can be empty)"
    echo ""
    echo "Tip: run 'python3 $TEMPLATE_DIR/scripts/list_zotero_libraries.py'"
    echo "     to see available Zotero libraries and collections."
    exit 1
fi

TARGET_DIR="$1"
PROJECT_NAME="$2"
LIBRARY_ID="${3:-}"
COLLECTION_ID="${4:-}"

# Derive a safe filename from the project name
TEX_BASENAME=$(echo "$PROJECT_NAME" | sed 's/ /_/g' | sed 's/[^a-zA-Z0-9_-]//g')
BIB_BASENAME=$(echo "$TEX_BASENAME" | tr '[:upper:]' '[:lower:]')

# ---- Get Zotero API key ----
ZOTERO_API_KEY="${ZOTERO_API_KEY:-}"
if [[ -z "$ZOTERO_API_KEY" && -f "$TEMPLATE_DIR/project.yaml" ]]; then
    ZOTERO_API_KEY=$(python3 -c "import yaml; print(yaml.safe_load(open('$TEMPLATE_DIR/project.yaml'))['zotero']['api_key'])")
fi
if [[ -z "$ZOTERO_API_KEY" || "$ZOTERO_API_KEY" == "YOUR_API_KEY_HERE" ]]; then
    echo "Error: No Zotero API key found."
    echo "Set ZOTERO_API_KEY env var or configure it in project.yaml."
    exit 1
fi

# ---- Prompt for library_id if not given ----
if [[ -z "$LIBRARY_ID" ]]; then
    echo "No library_id provided. Listing available libraries..."
    echo ""
    python3 "$TEMPLATE_DIR/scripts/list_zotero_libraries.py"
    echo ""
    echo -n "Enter the library_id to use: "
    read LIBRARY_ID
    echo -n "Enter a collection_id (leave empty for full library): "
    read COLLECTION_ID
fi

# ---- Create directory structure ----
echo "Creating project at: $TARGET_DIR"
mkdir -p "$TARGET_DIR"/{Figures,papers,papers_txt,scripts,build,.agent/workflows}

# ---- Copy infrastructure scripts ----
cp "$TEMPLATE_DIR/scripts/sync_zotero.py" "$TARGET_DIR/scripts/"
cp "$TEMPLATE_DIR/scripts/list_zotero_libraries.py" "$TARGET_DIR/scripts/"

# ---- Copy compile.sh ----
cp "$TEMPLATE_DIR/compile.sh" "$TARGET_DIR/compile.sh"
chmod +x "$TARGET_DIR/compile.sh"

# ---- Copy init.sh itself (so the new project can also be a template) ----
cp "$TEMPLATE_DIR/init.sh" "$TARGET_DIR/init.sh"
chmod +x "$TARGET_DIR/init.sh"

# ---- Generate project.yaml ----
cat > "$TARGET_DIR/project.yaml" <<YAML
project:
  name: "$PROJECT_NAME"
  main_tex: "${TEX_BASENAME}.tex"
  build_dir: "build"
  bib_file: "${BIB_BASENAME}.bib"

zotero:
  api_key: "$ZOTERO_API_KEY"
  library_id: "$LIBRARY_ID"
  library_type: "user"
  collection_id: "$COLLECTION_ID"
YAML

# ---- Generate main .tex file ----
cat > "$TARGET_DIR/${TEX_BASENAME}.tex" <<'LATEX'
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{microtype}
\usepackage{lmodern}
\usepackage[dvipsnames]{xcolor}
\usepackage{multicol}
\usepackage{float}
\usepackage{caption}
\DeclareGraphicsRule{.ai}{pdf}{.ai}{}

% Bibliography
LATEX

# Inject the project-specific bib file names
cat >> "$TARGET_DIR/${TEX_BASENAME}.tex" <<LATEX
\\usepackage[backend=biber,style=numeric]{biblatex}
\\addbibresource{${BIB_BASENAME}.bib}
\\addbibresource{manual_additions.bib}

\\title{${PROJECT_NAME}}
\\author{Author}
\\date{\\today}

\\begin{document}
\\maketitle

\\noindent\\textcolor{BrickRed}{\\textbf{Note:}} \\textcolor{BrickRed}{Any text written in red indicates citations/papers or ideas that need to be explored.}

\\begin{abstract}
% TODO: Write your abstract here.
\\end{abstract}

\\section{Introduction}
\\begin{multicols}{2}

% TODO: Write your introduction here.

\\end{multicols}

\\section{Methods}
\\begin{multicols}{2}

% TODO: Write your methods here.

\\end{multicols}

\\printbibliography
\\end{document}
LATEX

# ---- Create empty bib files ----
touch "$TARGET_DIR/${BIB_BASENAME}.bib"
touch "$TARGET_DIR/manual_additions.bib"

# ---- Generate .gitignore ----
cat > "$TARGET_DIR/.gitignore" <<'GIT'
# Build artifacts
build/
*.aux
*.bbl
*.bcf
*.blg
*.fdb_latexmk
*.fls
*.log
*.run.xml
*.synctex.gz
*.bbl-SAVE-ERROR

# OS
.DS_Store
Thumbs.db

# Python
__pycache__/
*.pyc
GIT

# ---- Generate MANIFEST.md ----
cat > "$TARGET_DIR/.agent/MANIFEST.md" <<MANIFEST
# AI Assistant Manifest — ${PROJECT_NAME}

This file is the AI assistant's persistent memory for this project.
Read it at the start of every conversation.

## Project Type

LaTeX scientific document, compiled with \`latexmk\`.

## Critical Workflow Rules

1. **Diff-first editing.** Every proposed change to any file must be shown
   as a diff in the implementation plan artifact for the user to approve
   **before** being applied. Never apply changes without approval.
2. **Compile after edits.** After applying approved changes to \`.tex\` or
   \`.bib\` files, run \`./compile.sh\` to verify the document builds.
3. **Red text for speculative ideas.** Use \`\\textcolor{BrickRed}{...}\` to
   mark new ideas, unverified claims, or placeholder citations
   (\`\\cite{missing_ref}\`) that need further exploration.
4. **Scientific tone.** Use precise terminology, correct nomenclature
   (italicised species names, proper gene/protein naming), and concise
   sentences. Avoid vague or conversational language.

## Project Configuration

All settings live in \`project.yaml\`:
- \`project.main_tex\` — the main \`.tex\` file name
- \`project.bib_file\` — the Zotero-synced bibliography file
- \`project.build_dir\` — output directory for compilation artifacts
- \`zotero.*\` — Zotero API credentials (can be overridden by env vars)

## Key Directories & Files

| Path | Purpose |
|---|---|
| \`${TEX_BASENAME}.tex\` | Main document |
| \`project.yaml\` | Project config (Zotero, TeX settings) |
| \`compile.sh\` | Build script (sync bib + latexmk) |
| \`build/\` | All compilation artifacts (gitignored) |
| \`Figures/\` | Images and figure PDFs |
| \`scripts/sync_zotero.py\` | Fetches bibliography from Zotero |
| \`${BIB_BASENAME}.bib\` | Auto-synced bibliography (do not edit manually) |
| \`manual_additions.bib\` | Manually added references |
| \`papers/\` | Reference PDFs |
| \`papers_txt/\` | Plain-text extracts of reference PDFs |
| \`papers_txt/INDEX.md\` | **Paper index** — summaries & citation keys |

## Literature Lookup

When answering questions about the project's literature:

1. **Read \`papers_txt/INDEX.md\`** first to identify the relevant paper(s).
2. **Load the full text** from the corresponding \`.txt\` file(s) in \`papers_txt/\`.
3. Answer with the full paper(s) as context — do not guess or paraphrase
   from memory alone.

## Compilation

\`\`\`bash
./compile.sh          # Sync Zotero + compile
./compile.sh clean    # Remove build artifacts
\`\`\`

## Bibliography

- \`${BIB_BASENAME}.bib\` is auto-generated by \`scripts/sync_zotero.py\` from Zotero.
  Do **not** edit this file by hand.
- \`manual_additions.bib\` is for references not in the Zotero library.
  Edit this file manually when needed.
MANIFEST

# ---- Generate workflow files ----
cat > "$TARGET_DIR/.agent/workflows/apply-changes.md" <<'WORKFLOW'
---
description: How to apply changes to the LaTeX document or any file
---
1. Propose the change as a diff in the implementation plan.
2. Wait for the user to approve.
3. Apply the change using the appropriate edit tool.
4. Recompile with `./compile.sh`.
5. Confirm the build succeeded.
WORKFLOW

cat > "$TARGET_DIR/.agent/workflows/compile.md" <<'WORKFLOW'
---
description: Recompile the LaTeX document and update the PDF.
---
// turbo-all

1. Run `./compile.sh` from the project root.
2. Check exit code and review any warnings in the output.
3. The compiled PDF is at `build/<main_tex_basename>.pdf`.
4. To clean all artifacts: `./compile.sh clean`.
WORKFLOW

# ---- Generate empty paper index ----
cat > "$TARGET_DIR/papers_txt/INDEX.md" <<'INDEX'
# Paper Index

Quick-reference index for the AI assistant. When a literature question arises,
scan the summaries below to decide which full paper(s) to load from this folder.

---

<!-- Add paper summaries here as you add papers to the project. -->
<!-- Use the format from the template project's INDEX.md. -->
INDEX

# ---- Generate README ----
cat > "$TARGET_DIR/README.md" <<README
# ${PROJECT_NAME}

LaTeX scientific document.

## Prerequisites

| Tool | Install |
|---|---|
| TeX Live (pdflatex, latexmk, biber) | \`brew install --cask mactex\` or [tug.org/mactex](https://tug.org/mactex/) |
| Python 3 | \`brew install python\` |
| PyYAML | \`pip3 install pyyaml\` |
| Requests | \`pip3 install requests\` |

## Project Structure

\`\`\`
$(basename "$TARGET_DIR")/
├── .agent/                    # AI assistant config
│   ├── MANIFEST.md            # AI memory & workflow rules
│   └── workflows/
│       ├── apply-changes.md   # Change-approval workflow
│       └── compile.md         # Compilation workflow
├── .gitignore
├── build/                     # Compilation artifacts (gitignored)
├── Figures/                   # Images and figures
├── scripts/
│   ├── sync_zotero.py         # Fetches .bib from Zotero API
│   └── list_zotero_libraries.py
├── papers/                    # Reference PDFs
├── papers_txt/                # Plain-text extracts
│   └── INDEX.md               # Paper index (summaries + citation keys)
├── compile.sh                 # Main build script
├── init.sh                    # Create a new project from this template
├── project.yaml               # Project config (Zotero, TeX)
├── ${TEX_BASENAME}.tex        # Main document
├── ${BIB_BASENAME}.bib        # Auto-synced bibliography
├── manual_additions.bib       # Manual bibliography entries
└── README.md                  # This file
\`\`\`

## Compilation

\`\`\`bash
./compile.sh          # Sync bibliography + compile PDF
./compile.sh clean    # Clean all build artifacts
\`\`\`

The compiled PDF is written to \`build/${TEX_BASENAME}.pdf\`.

## Bibliography

- **\`${BIB_BASENAME}.bib\`** — Auto-generated from Zotero. Do not edit manually.
- **\`manual_additions.bib\`** — For references not in Zotero.

## Creating a New Project From This Template

\`\`\`bash
# List available Zotero libraries
python3 scripts/list_zotero_libraries.py

# Scaffold a new project
./init.sh ~/Documents/PhD/New_Paper "My New Paper" <library_id> [collection_id]
\`\`\`
README

echo ""
echo "✅ Project '${PROJECT_NAME}' created at: ${TARGET_DIR}"
echo ""
echo "Next steps:"
echo "  cd ${TARGET_DIR}"
echo "  ./compile.sh          # Sync Zotero + compile"
echo "  open build/${TEX_BASENAME}.pdf"
