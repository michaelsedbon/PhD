---
name: fetch-papers
description: Download PDFs for papers from the Notion bibliography using Sci-Hub, and save them locally
---

# Fetch Papers Skill

Download PDFs for papers in the Notion bibliography database that don't yet have a local PDF.

## How it works

The script `scripts/fetch_papers.py`:

1. **Queries** the Notion bibliography database for all papers
2. **Extracts DOIs** from the `URL` property (supports `doi.org/`, `nature.com/`, `science.org/`, etc.)
3. **Checks** if a PDF already exists in `papers/`
4. **Downloads** missing PDFs from Sci-Hub (tries multiple mirrors)
5. **Reports** which papers were downloaded, skipped, or failed

## Usage

### Download all missing papers
```bash
python3 scripts/fetch_papers.py
```

### Preview what would be downloaded (no downloads)
```bash
python3 scripts/fetch_papers.py --dry-run
```

### Download papers matching a filter (by title keyword)
```bash
python3 scripts/fetch_papers.py --filter "CRISPR"
```

### Force re-download even if PDF exists
```bash
python3 scripts/fetch_papers.py --force
```

### Check which mirrors are alive
```bash
python3 scripts/fetch_papers.py --check-mirrors
```

### Check mirrors, then download with working ones first
```bash
python3 scripts/fetch_papers.py --check-mirrors --dry-run
```

## Output

- PDFs are saved to `papers/` with sanitized filenames derived from the paper title
- A summary is printed at the end showing downloaded, skipped, and failed papers

## Notes

- Sci-Hub mirrors change frequently. Use `--check-mirrors` to test which are alive and reorder automatically.
- The mirror list in the script is annotated with last-checked dates — update as needed.
- Some papers may not be on Sci-Hub (e.g. very recent or open-access). These are reported as failed.
- Rate limiting: the script waits 3 seconds between downloads to avoid being blocked.
- DOI extraction handles common URL patterns from Nature, Science, PLoS, Frontiers, etc.
