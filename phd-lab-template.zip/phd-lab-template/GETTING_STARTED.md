# 🚀 Getting Started — Set Up Your AI-Powered Lab Workspace

Welcome! This guide will walk you through setting up everything from scratch. By the end, you'll have a fully working AI lab assistant that can sync your experiments from Notion, manage your bibliography, explore paper networks, and help you write grant proposals.

**Time needed:** ~20 minutes

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Set Up Notion](#2-set-up-notion)
3. [Set Up Airtable](#3-set-up-airtable-optional)
4. [Set Up Zotero](#4-set-up-zotero)
5. [Fill In Your Credentials](#5-fill-in-your-credentials)
6. [Install Python Dependencies](#6-install-python-dependencies)
7. [Verify Everything Works](#7-verify-everything-works)
8. [Set Up LaTeX (for Grant Proposals)](#8-set-up-latex-for-grant-proposals)
9. [What's Next](#9-whats-next)

---

## 1. Prerequisites

Make sure you have these installed:

| Tool | How to install | Check |
|------|---------------|-------|
| **Python 3** | `brew install python` (Mac) or [python.org](https://www.python.org/) | `python3 --version` |
| **Git** | `brew install git` (Mac) or [git-scm.com](https://git-scm.com/) | `git --version` |
| **VS Code** | [code.visualstudio.com](https://code.visualstudio.com/) | — |

You'll also want the **Gemini Code Assist** extension in VS Code (or whichever AI assistant you're using).

---

## 2. Set Up Notion

You need **two Notion databases** and one **integration** (API token).

### Step 2a: Create a Notion Integration

1. Go to [notion.so/my-integrations](https://www.notion.so/my-integrations)
2. Click **"+ New integration"**
3. Give it a name (e.g. "Lab Assistant")
4. Select your workspace
5. Click **Submit**
6. 🔑 **Copy the "Internal Integration Secret"** — it starts with `ntn_` or `secret_`
   - This is your **Notion token**. Save it somewhere safe for now.

### Step 2b: Create the Lab Notebook Database

This is where your experiments live.

1. Create a new **full-page database** in Notion
2. Add these properties (columns):

   | Property Name | Type | Notes |
   |---|---|---|
   | **Name** | Title | (default — already there) |
   | **Exp Number** | Select | Values like `EXP_001`, `EXP_002`, etc. |
   | **Start Date** | Date | When the experiment started |
   | **Airtable Link** | Multi-select | (optional) Link to Airtable sample IDs |

3. 🔑 **Get the database ID:** Open the database in Notion as a full page. The URL looks like:
   ```
   https://www.notion.so/your-workspace/DATABASE_ID_HERE?v=xxx
   ```
   The **32-character hex string** before `?v=` is your database ID.

4. **Connect the integration:** In your database, click `...` → **Connections** → Add your "Lab Assistant" integration.

### Step 2c: Create the Bibliography Database

This is where your papers and reading list live.

1. Create another **full-page database** in Notion
2. Add these properties:

   | Property Name | Type | Notes |
   |---|---|---|
   | **Paper name** | Title | Paper title |
   | **Subject** | Multi-select | Topic tags (e.g. "CRISPR", "Machine Learning") |
   | **Project relevance** | Multi-select | Project area |
   | **URL** | URL | DOI link or paper URL |
   | **Files & media** | Files | Upload the PDF |
   | **Note** | Rich text | Your notes on the paper |

3. 🔑 **Get the database ID** (same method as above).
4. **Connect the integration** (same as above).

---

## 3. Set Up Airtable (Optional)

Airtable is used for lab inventory tracking (reagents, labware, strains). This is optional — the core paper/experiment workflows work without it.

### Step 3a: Create an Airtable Base

1. Go to [airtable.com](https://airtable.com/) and sign in (or create a free account)
2. Create a new **base** (database)
3. Create two tables:
   - **Reagents** — columns: Name, Reference Number, Supplier, Link, Storage, Notes, Type, Project
   - **Labware** — columns: Name, Reference Number, Supplier, Link, Storage, Notes

4. 🔑 **Get your Base ID:** Open the base. The URL looks like:
   ```
   https://airtable.com/appXXXXXXXXXXXXXX/...
   ```
   The part starting with `app` is your Base ID.

### Step 3b: Create a Personal Access Token

1. Go to [airtable.com/create/tokens](https://airtable.com/create/tokens)
2. Click **"Create new token"**
3. Name it "Lab Assistant"
4. **Scopes:** Add `data.records:read` and `data.records:write`
5. **Access:** Add your base
6. Click **Create token**
7. 🔑 **Copy the token** — it starts with `pat`

---

## 4. Set Up Zotero

Zotero is used for reference management, especially for grant proposals. The AI can automatically sync your bibliography and add papers it finds.

### Step 4a: Install Zotero

1. Download from [zotero.org](https://www.zotero.org/download/)
2. Create a free account at [zotero.org/user/register](https://www.zotero.org/user/register)

### Step 4b: Create an API Key

1. Go to [zotero.org/settings/keys](https://www.zotero.org/settings/keys)
2. Click **"Create new private key"**
3. Give it a name (e.g. "Lab Assistant")
4. **Permissions:**
   - ✅ Allow library access
   - ✅ Allow write access
5. Click **Save Key**
6. 🔑 **Copy the key**

### Step 4c: Find Your Library ID

1. Go to [zotero.org/settings/keys](https://www.zotero.org/settings/keys)
2. Your **userID** is shown at the top of the page — this is your library ID
3. (Optional) Create a **collection** called "AI Agent" in your Zotero library for papers the AI downloads. Note its collection ID.

### Step 4d: Find a Collection ID (Optional)

If you want the AI assistant to save papers to a specific collection:

1. Open your Zotero library in the web interface
2. Click on the collection
3. The URL will contain the collection ID (looks like `ABC12345`)

Or use the helper script after setup:
```bash
python3 grant_template/scripts/list_zotero_libraries.py
```

---

## 5. Fill In Your Credentials

Open **`config.yaml`** in your editor and fill in all the values you collected:

```yaml
notion:
  token: "ntn_YOUR_INTEGRATION_TOKEN"           # ← from Step 2a
  lab_notebook_db: "abc123def456..."             # ← from Step 2b
  bibliography_db: "789ghi012jkl..."             # ← from Step 2c

airtable:
  token: "patXXXXXXX.XXXXXXXXX"                 # ← from Step 3b
  base_id: "appXXXXXXXXXXXXXX"                  # ← from Step 3a

zotero:
  api_key: "YOUR_ZOTERO_API_KEY"                 # ← from Step 4b
  library_id: "YOUR_USER_ID"                     # ← from Step 4c
  library_type: "user"
  agent_collection_id: "ABC12345"                # ← from Step 4d (optional)
```

> ⚠️ **Never commit this file to git.** It's already in `.gitignore`.

---

## 6. Install Python Dependencies

```bash
pip3 install requests pyyaml pymupdf
```

That's it! These three packages power all the sync scripts.

---

## 7. Verify Everything Works

### Test Notion connection:
```bash
python3 scripts/notion_client.py --test
```
You should see your database names and entry counts.

### Test bibliography sync:
```bash
python3 scripts/sync_bibliography.py --list
```
This lists all papers in your bibliography database.

### Test experiment sync:
```bash
python3 scripts/sync_experiments.py --list
```
This lists all experiments in your lab notebook database.

### Test Airtable (if configured):
```bash
python3 scripts/fetch_airtable.py --test
```

### If something fails:

| Error | Fix |
|-------|-----|
| `Could not validate credentials` | Double-check your Notion token in `config.yaml` |
| `Could not find database` | Verify the database IDs, and check the integration is connected to both databases |
| `401 Unauthorized` (Airtable) | Check your Airtable token and that scopes are correct |
| `403 Forbidden` (Zotero) | Make sure write access is enabled on your Zotero API key |

---

## 8. Set Up LaTeX (for Grant Proposals)

If you want to use the grant proposal system:

### Install LaTeX:
```bash
# Mac
brew install --cask mactex

# Or download from https://tug.org/mactex/
```

### Install Pandoc (for DOCX export):
```bash
brew install pandoc
```

### Create your first grant proposal:
```bash
./grant_template/init.sh ~/Documents/My_Grant "My First Grant" YOUR_ZOTERO_LIBRARY_ID
```

### Compile it:
```bash
cd ~/Documents/My_Grant
./compile.sh
```

---

## 9. What's Next?

You're all set! Here's what to do now:

1. **Read [TUTORIAL.md](TUTORIAL.md)** — it explains all the workflows with real examples
2. **Try `/catch-up`** — ask your AI assistant to run a catch-up sync
3. **Add your first paper** to your Notion bibliography database and run `/sync-bibliography`
4. **Create your first experiment** in Notion and run `/sync-experiments`

### Available slash commands:

| Command | What it does |
|---------|--------------|
| `/catch-up` | Sync everything and report what's new |
| `/sync-bibliography` | Download and index new papers from Notion |
| `/sync-experiments` | Sync experiment entries from Notion |
| `/update-experiment` | Log data/analysis to an experiment |
| `/push-experiment-to-notion` | Push local experiment docs to Notion |
| `/new-grant-project` | Create a new LaTeX grant proposal |
| `/compile-grant` | Compile a grant proposal PDF |
| `/create-app` | Scaffold a new lab web application |

Happy researching! 🧬
