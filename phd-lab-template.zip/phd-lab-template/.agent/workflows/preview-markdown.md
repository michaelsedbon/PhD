---
description: Open any markdown file in the Experiment Viewer for rendered preview
---

# Preview Markdown in Experiment Viewer

To preview any `.md` file in the Experiment Viewer, open this URL in the user's browser:

```
http://localhost:3000/?preview={absolute_path_to_md_file}
```

The Experiment Viewer must be running (frontend on port 3000, backend on port 8001).

## API Endpoints

- **`GET http://localhost:8001/api/preview?path=...`** — returns JSON with `content`, `filename`, `dir`
- **`GET http://localhost:8001/api/preview-media?dir=...&path=...`** — serves referenced media

## Implementation

- Backend: `applications/experiment-viewer/server/main.py`
- Frontend: `applications/experiment-viewer/dashboard/src/app/page.tsx`
