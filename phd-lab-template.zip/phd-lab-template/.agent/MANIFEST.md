# AI Assistant Manifest — PhD Lab

This file is the AI lab assistant's persistent memory for this workspace.
Read it at the start of every conversation.

## ⚡ FIRST RUN — Check This Every Time

At the start of **every conversation**, check if `config.yaml` still contains placeholder values (e.g. `YOUR_NOTION_INTEGRATION_TOKEN_HERE`). If it does, the user hasn't set up yet. Immediately offer:

> 👋 It looks like this workspace hasn't been set up yet! Type **`/setup`** and I'll walk you through everything step by step — it takes about 15 minutes.

If `config.yaml` is already configured, greet them normally and offer a quick recap of what they can do if this seems like an early conversation.

If the user seems new and asks "what can I do?" or "how does this work?", run the `/tour` workflow.

## Project Type

Personal lab workspace for a PhD project. Integrates with Notion (lab notebook + bibliography), Airtable (reagents, labware, experiment data), and Zotero (reference management).

## Key Data Sources

| Source | Platform | Config Key |
|---|---|---|
| Lab Notebook | Notion | `notion.lab_notebook_db` |
| Bibliography | Notion | `notion.bibliography_db` |
| Reagents & Labware | Airtable | `airtable.base_id` |
| References | Zotero | `zotero.library_id` |

All credentials are in `config.yaml` (gitignored). See `GETTING_STARTED.md` to set them up.

## Notion Lab Notebook Schema

| Property | Type | Example |
|---|---|---|
| Name | title | "Experiment title" |
| Exp Number | select | EXP_001 |
| Start Date | date | 2026-02-20 |
| Airtable Link | multi_select | MS_S_001 |

## Notion Bibliography Schema

| Property | Type | Notes |
|---|---|---|
| Paper name | title | Paper title |
| Subject | multi_select | Topic tags |
| Project relevance | multi_select | Project area |
| URL | url | Paper URL/DOI |
| Files & media | files | PDF attachment |
| Note | rich_text | Notes on the paper |

## Airtable Schema

**Reagents table:** Name, Reference Number, Supplier, Link, Storage, Notes, Type, Project
**Labware table:** Name, Reference Number, Supplier, Link, Storage, Notes

## Key Directories & Files

| Path | Purpose |
|---|---|
| `config.yaml` | API credentials (gitignored) |
| `scripts/` | Python sync scripts |
| `papers/` | Downloaded reference PDFs (user's collection) |
| `papers_txt/` | Plain-text extracts of PDFs |
| `papers_txt/INDEX.md` | **Paper index** — summaries & metadata for AI lookup |
| `agent_papers/` | PDFs downloaded by the AI assistant during conversations |
| `agent_papers_txt/` | Plain-text extracts of agent-downloaded PDFs |
| `agent_papers_txt/INDEX.md` | **Agent paper index** — verified citations |
| `experiments/` | Per-experiment folders |
| `experiments/EXP_INDEX.md` | **Experiment index** — summaries for AI lookup |
| `grant_template/` | Scaffolding tools for new LaTeX grant proposals |

## Literature Lookup

When answering questions about the project's literature:

1. **Read `papers_txt/INDEX.md`** first to identify the relevant paper(s).
2. **Load the full text** from the corresponding `.txt` file(s) in `papers_txt/`.
3. Answer with the full paper(s) as context — do not guess or paraphrase from memory alone.

## ⚠️ MANDATORY: Verify Before Citing

**ANY TIME you make a factual claim backed by a paper — whether recommending, citing, referencing, or quoting — you MUST follow this procedure. This is not optional. It applies even if the user didn't ask you to verify.**

1. **Check if you already have it** — look in `papers_txt/INDEX.md` and `agent_papers_txt/INDEX.md` first. If the paper is already there, skip to step 4 (read the text directly).
2. **Download the paper** using `scripts/fetch_papers.py` (Sci-Hub) → save to `agent_papers/`
3. **Add to Zotero** agent collection (collection ID in `config.yaml` under `zotero.agent_collection_id`)
4. **Extract text** (PyMuPDF or pdftotext) → save to `agent_papers_txt/`
5. **Read the extracted text** and verify your claim is actually supported
6. **Update `agent_papers_txt/INDEX.md`** with the paper's metadata and verified finding
7. **Only then** present the citation to the user, noting you verified it

If the download fails, **say so explicitly** — never pretend you verified a paper you didn't read.

See `.agent/skills/verify-paper-claims/SKILL.md` for the full procedure.

## Paper Network Exploration

When the user asks about **related papers**, **prior work**, or **"has anyone done X"**, use the paper network exploration script to find connected papers via Semantic Scholar:

```bash
python3 scripts/explore_paper_network.py --doi "<DOI>" --keyword "relevant term" --limit 20
```

See `.agent/skills/explore-paper-network/SKILL.md` for full usage.

## Experiment Workflow

### Reading experiments

1. **Read `experiments/EXP_INDEX.md`** first to identify the relevant experiment(s).
2. **Load `experiments/EXP_XXX/summary.md`** for full details.

### Creating/updating experiment files

When you create or rename a `.md` file inside an experiment folder, you **must** also:

1. **Update the Document Index** at the top of `summary.md` — add a row with the file link, description, and colored type badge (see Badge Color Scheme below).
2. **Update `experiments/EXP_INDEX.md`** — add the file to the experiment's Reports table.

### Experiment folder structure

All experiments follow this layout:

```
EXP_XXX/
├── summary.md          ← Main entry point (has Document Index at top)
├── LOG.md              ← Chronological log
├── *.md                ← Reports, literature reviews, etc.
├── data/               ← Figures, CSVs, interactive plots
├── scripts/            ← Python scripts & notebooks
└── [app folders]/      ← Viewer apps, tools, etc.
```

**Rules:**
- `.md` files live at the experiment root (not in subfolders)
- Python scripts go in `scripts/`
- Data files go in `data/`
- The `summary.md` Document Index must always be kept in sync with the actual `.md` files

## Badge Color Scheme

When creating document index tables in experiment `summary.md` files, **always** use these colors for type badges (inline `<span>` with `border-radius:12px`):

| Type | Color | Hex | Text |
|------|-------|-----|------|
| Main | Blue | `#1a6fff` | `#fff` |
| Report | Cyan | `#4fc3f7` | `#0d1117` |
| Literature | Purple | `#ab47bc` | `#fff` |
| Reference | Green | `#66bb6a` | `#0d1117` |
| Log | Orange | `#d29922` | `#0d1117` |

Template: `<span style="background:HEX;color:TEXT;padding:2px 8px;border-radius:12px;font-size:11px">Label</span>`

## Grant Proposals

Use the `grant_template/` directory to scaffold new LaTeX grant proposals. See `/new-grant-project` workflow or run:

```bash
./grant_template/init.sh <target_dir> "<Project Name>" [library_id] [collection_id]
```

## Credentials

Stored in `config.yaml` (gitignored). Placeholders in `.env.example`. See `GETTING_STARTED.md` for setup instructions.
