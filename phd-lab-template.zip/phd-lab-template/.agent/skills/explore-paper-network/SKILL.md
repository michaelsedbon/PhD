---
name: explore-paper-network
description: Explore the citation network around seed papers using Semantic Scholar to find related work
---

# Explore Paper Network

Use this skill when the user asks about **related papers**, **prior work**, **who else has done X**, or **connected papers**. It queries the Semantic Scholar API to map the citation network around seed papers.

## When to use

- User asks: "any papers related to X?"
- User asks: "has anyone done something similar to X?"
- User asks: "what papers cite X?"
- You want to find relevant literature around a topic anchored by known papers

## How it works

The script `scripts/explore_paper_network.py` uses the **Semantic Scholar API** (free, no key required):

1. **Resolves** seed papers by DOI, title, or Semantic Scholar ID
2. **Fetches citations** — who cited this paper?
3. **Fetches references** — what did this paper build on?
4. **Gets ML recommendations** — Semantic Scholar's similar paper suggestions
5. **Filters & ranks** by citation count, keywords, and year
6. **Multi-seed overlap** — when given multiple seeds, finds papers appearing in multiple networks (= highly relevant)

## Usage

### Single seed paper
```bash
python3 scripts/explore_paper_network.py --doi "10.1038/ncomms9101"
```

### Multiple seed papers (finds shared network)
```bash
python3 scripts/explore_paper_network.py \
    --doi "10.1038/ncomms9101" \
    --doi "10.1126/science.aad8711" \
    --doi "10.1038/s41586-019-1192-5"
```

### Search by title
```bash
python3 scripts/explore_paper_network.py --title "CATCH Cas9 targeting chromosome"
```

### Filter by keyword and minimum citations
```bash
python3 scripts/explore_paper_network.py \
    --doi "10.1038/ncomms9101" \
    --keyword "E. coli" --keyword "genome" \
    --min-citations 10
```

### Save markdown report
```bash
python3 scripts/explore_paper_network.py \
    --doi "10.1038/ncomms9101" \
    --output agent_papers_txt/network_report.md
```

### All options
```
--doi DOI           Seed paper DOI (can repeat)
--title TITLE       Search by title (can repeat)
--id ID             Semantic Scholar ID (can repeat)
--keyword KEYWORD   Filter by keyword in title/abstract (can repeat)
--min-citations N   Only show papers with >= N citations
--min-year YEAR     Only show papers from YEAR onwards
--limit N           Max papers per category (default: 30)
--max-network N     Max papers to fetch per direction (default: 200)
--output PATH       Save markdown report to file
--no-citations      Skip citations
--no-references     Skip references
--no-recommendations  Skip ML recommendations
--abstract          Show abstracts in output
```

## Recommended workflow

1. **Identify seed papers** from the user's question or existing `INDEX.md` files
2. **Run the script** with relevant DOIs
3. **Review output** — look for highly-cited papers and multi-seed overlaps
4. **Download promising papers** using the `verify-paper-claims` skill
5. **Summarize findings** for the user

## Rate limits

- Semantic Scholar allows ~1 request/second without an API key
- The script includes built-in rate limiting (0.35s between requests)
- For large networks, fetching may take 30–60 seconds
