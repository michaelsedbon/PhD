import requests
import sys
import os
import yaml

# --- CONFIGURATION (from project.yaml) ---
project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
config_path = os.path.join(project_dir, 'project.yaml')

with open(config_path) as f:
    config = yaml.safe_load(f)

ZOTERO_API_KEY = os.environ.get('ZOTERO_API_KEY', config['zotero']['api_key'])
ZOTERO_LIBRARY_ID = os.environ.get('ZOTERO_LIBRARY_ID', str(config['zotero']['library_id']))
ZOTERO_LIBRARY_TYPE = os.environ.get('ZOTERO_LIBRARY_TYPE', config['zotero']['library_type'])
ZOTERO_COLLECTION_ID = os.environ.get('ZOTERO_COLLECTION_ID', config['zotero'].get('collection_id', ''))

BIB_FILE = config['project']['bib_file']

def sync_bibliography():
    if ZOTERO_API_KEY == 'YOUR_API_KEY_HERE' or ZOTERO_LIBRARY_ID == 'YOUR_LIBRARY_ID_HERE':
        print("Error: Zotero API Key or Library ID not set.")
        print("Please edit project.yaml or set ZOTERO_API_KEY and ZOTERO_LIBRARY_ID environment variables.")
        sys.exit(1)

    print(f"Syncing bibliography from Zotero library {ZOTERO_LIBRARY_ID}...")
    
    base_url = f"https://api.zotero.org/{ZOTERO_LIBRARY_TYPE}s/{ZOTERO_LIBRARY_ID}/"
    if ZOTERO_COLLECTION_ID:
        endpoint = f"collections/{ZOTERO_COLLECTION_ID}/items"
    else:
        endpoint = "items"
        
    url = f"{base_url}{endpoint}?format=bibtex&limit=100"
    
    headers = {
        'Zotero-API-Key': ZOTERO_API_KEY,
        'Zotero-API-Version': '3'
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        with open(BIB_FILE, 'w') as f:
            f.write(response.text)
            
        print(f"Successfully updated {BIB_FILE}")
    except Exception as e:
        print(f"Failed to sync with Zotero: {e}")
        sys.exit(1)

if __name__ == "__main__":
    sync_bibliography()
