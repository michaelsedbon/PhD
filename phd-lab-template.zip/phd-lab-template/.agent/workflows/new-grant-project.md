---
description: Create a new LaTeX grant proposal project from the template
---

# New Grant Project

When the user asks to create a new grant proposal or paper, follow these steps:

1. **Ask the user for:**
   - Project name (e.g. "RBD Evolution Paper")
   - Target folder location (e.g. `~/Documents/PhD/My_Grant`)
   - Optionally, which Zotero library to use

2. **If the user doesn't know their Zotero library ID**, run:
   ```bash
   python3 grant_template/scripts/list_zotero_libraries.py
   ```
   Show them the output and let them pick a library and (optionally) a collection.

3. **Run the init script:**
   ```bash
   ./grant_template/init.sh "<target_dir>" "<Project Name>" <library_id> [collection_id]
   ```

4. **Verify** by confirming the directory was created and listing its contents.

5. **Offer next steps:**
   - Open the new project in the editor
   - Do an initial compile: `cd <target_dir> && ./compile.sh`
   - Start writing content
