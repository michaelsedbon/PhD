---
description: Append notes, data, or analysis to an experiment's summary.md and sync all content to its Notion page
---

# Update Experiment

// turbo-all

Use this workflow whenever the user wants to log new findings, analysis, data, or notes to an experiment.

## 1. Identify the experiment

- Ask the user which experiment (e.g. EXP_001) if not obvious from context.
- The experiment folder is at `experiments/EXP_XXX/`.
- The summary file is `experiments/EXP_XXX/summary.md`.

## 2. Append to summary.md

- **Always append** new content at the end of `summary.md`, never overwrite existing content.
- Start each new entry with a divider and a dated heading:
  ```markdown
  ---

  ## [Title of Update] (YYYY-MM-DD)
  ```
- Include all relevant details:
  - What was done / observed
  - Data files created (with file names and descriptions)
  - Results tables with measurements
  - Plots (as `![caption](data/filename.png)`)
  - Analysis and conclusions
  - Next steps
- If plots need to be generated from data, generate them with matplotlib and save as PNG in the experiment's `data/` folder.

## 3. Update EXP_INDEX.md

- Add a one-line summary of the update to `experiments/EXP_INDEX.md` under the corresponding experiment entry.
- Keep the index entry concise — just the date and key finding.

## 4. Sync to Notion

The Notion page must mirror everything in summary.md. Follow these steps:

### 4a. Find the Notion page

```python
import sys; sys.path.insert(0, 'scripts')
from notion_client import (CONFIG, query_database, get_property_value, 
                            get_block_children, append_blocks_to_page, HEADERS)

pages = query_database(CONFIG['notion']['lab_notebook_db'])
for page in pages:
    if get_property_value(page, 'Exp Number') == 'EXP_XXX':
        page_id = page['id']
        break
```

### 4b. Convert summary content to Notion blocks

Use these block types to faithfully represent the markdown:

| Markdown | Notion block type |
|----------|------------------|
| `## Heading` | `heading_2` |
| `### Heading` | `heading_3` |
| `- bullet` | `bulleted_list_item` |
| `1. item` | `numbered_list_item` |
| Paragraph text | `paragraph` |
| `---` | `divider` |
| Code block | `code` |
| Table | `table` with `table_row` children |
| Callout / important note | `callout` with emoji icon |

For bold/code formatting in text, use annotations:
```python
def text(content, bold=False, code=False):
    t = {'type': 'text', 'text': {'content': content}}
    if bold or code:
        t['annotations'] = {}
        if bold: t['annotations']['bold'] = True
        if code: t['annotations']['code'] = True
    return t
```

### 4c. Upload images (if any)

Notion requires externally hosted image URLs. Upload images using:

```bash
curl -s -F "reqtype=fileupload" -F "time=24h" -F "fileToUpload=@<path>" https://litterbox.catbox.moe/resources/internals/api.php
```

Then create an image block:
```python
{
    'object': 'block',
    'type': 'image',
    'image': {
        'type': 'external',
        'external': {'url': '<uploaded_url>'},
        'caption': [{'type': 'text', 'text': {'content': '<description>'}}]
    }
}
```

> **Note:** Catbox URLs expire after 24h. The permanent copies are in the experiment's `data/` folder.

### 4d. Append blocks to the Notion page

- Use `append_blocks_to_page(page_id, blocks)` to append at the end.
- To insert at a specific position, use the `after` parameter:
  ```python
  requests.patch(
      f'https://api.notion.com/v1/blocks/{page_id}/children',
      headers=HEADERS,
      json={'after': '<block_id>', 'children': blocks}
  )
  ```
- Notion API limits ~100 blocks per request. Split into batches if needed with `time.sleep(0.5)` between them.

### 4e. Deleting/replacing blocks

If you need to replace existing content (not just append):
```python
# List blocks
blocks = get_block_children(page_id)

# Delete specific blocks
for b in blocks_to_delete:
    requests.delete(f'https://api.notion.com/v1/blocks/{b["id"]}', headers=HEADERS)
    time.sleep(0.15)  # rate limit
```

## 5. Confirm

- Report what was added to summary.md
- Report how many blocks were pushed to Notion
- Mention any images uploaded
