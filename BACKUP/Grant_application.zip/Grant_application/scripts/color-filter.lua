-- Pandoc Lua filter for docx output:
-- 1. Preserve \textcolor{ColorName}{text} as colored text
-- 2. Handle \captionof{figure}{...} captions
-- 3. Move all figures + captions to a "Figures" section at the end
--
-- Pandoc 3.9+ natively parses \textcolor into Span with style="color: ColorName"
-- \captionof is passed through as RawInline when using -f latex+raw_tex

local color_map = {
  -- dvipsnames
  BrickRed    = "CB4154",
  Red         = "FF0000",
  Blue        = "0000FF",
  Green       = "00FF00",
  Black       = "000000",
  White       = "FFFFFF",
  Cyan        = "00FFFF",
  Magenta     = "FF00FF",
  Yellow      = "FFFF00",
  Orange      = "FF6600",
  Violet      = "800080",
  Purple      = "800080",
  Brown       = "A52A2A",
  Gray        = "808080",
  NavyBlue    = "000080",
  RoyalBlue   = "4169E1",
  ForestGreen = "228B22",
  OliveGreen  = "6B8E23",
  Maroon      = "800000",
  Plum        = "8B668B",
  Salmon      = "FA8072",
  Turquoise   = "40E0D0",
  -- basic
  red         = "FF0000",
  blue        = "0000FF",
  green       = "00FF00",
  black       = "000000",
  white       = "FFFFFF",
  cyan        = "00FFFF",
  magenta     = "FF00FF",
  yellow      = "FFFF00",
  orange      = "FF6600",
}

-- Extract color name from a style attribute like "color: BrickRed"
local function extract_color_from_style(style_str)
  if not style_str then return nil end
  local color_name = style_str:match("color:%s*(%S+)")
  return color_name
end

-- Recursively collect OpenXML runs from inlines, applying color and formatting
local function collect_runs(inlines, color_hex, is_bold, is_italic)
  local xml = ""
  for _, inline in ipairs(inlines) do
    if inline.tag == "Str" then
      local rpr = {}
      if is_bold then table.insert(rpr, "<w:b/><w:bCs/>") end
      if is_italic then table.insert(rpr, "<w:i/><w:iCs/>") end
      table.insert(rpr, string.format('<w:color w:val="%s"/>', color_hex))
      xml = xml .. string.format(
        '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>',
        table.concat(rpr), inline.text
      )
    elseif inline.tag == "Space" or inline.tag == "SoftBreak" then
      local rpr = {}
      if is_bold then table.insert(rpr, "<w:b/><w:bCs/>") end
      if is_italic then table.insert(rpr, "<w:i/><w:iCs/>") end
      table.insert(rpr, string.format('<w:color w:val="%s"/>', color_hex))
      xml = xml .. string.format(
        '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve"> </w:t></w:r>',
        table.concat(rpr)
      )
    elseif inline.tag == "Strong" then
      xml = xml .. collect_runs(inline.content, color_hex, true, is_italic)
    elseif inline.tag == "Emph" then
      xml = xml .. collect_runs(inline.content, color_hex, is_bold, true)
    elseif inline.tag == "Span" then
      xml = xml .. collect_runs(inline.content, color_hex, is_bold, is_italic)
    elseif inline.tag == "Cite" then
      local cite_text = pandoc.utils.stringify(inline)
      local rpr = {}
      if is_bold then table.insert(rpr, "<w:b/><w:bCs/>") end
      if is_italic then table.insert(rpr, "<w:i/><w:iCs/>") end
      table.insert(rpr, string.format('<w:color w:val="%s"/>', color_hex))
      xml = xml .. string.format(
        '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>',
        table.concat(rpr), cite_text
      )
    elseif inline.tag == "LineBreak" then
      xml = xml .. '<w:r><w:br/></w:r>'
    elseif inline.tag == "RawInline" then
      if inline.format == "openxml" then
        xml = xml .. inline.text
      end
    else
      local text = pandoc.utils.stringify(inline)
      if text ~= "" then
        local rpr = {}
        if is_bold then table.insert(rpr, "<w:b/><w:bCs/>") end
        if is_italic then table.insert(rpr, "<w:i/><w:iCs/>") end
        table.insert(rpr, string.format('<w:color w:val="%s"/>', color_hex))
        xml = xml .. string.format(
          '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>',
          table.concat(rpr), text
        )
      end
    end
  end
  return xml
end

-- Extract content inside balanced braces starting at position pos
local function extract_braced(text, pos)
  if text:sub(pos, pos) ~= "{" then return nil, pos end
  local depth = 0
  local start = pos + 1
  local i = pos
  while i <= #text do
    local ch = text:sub(i, i)
    if ch == "{" then
      depth = depth + 1
    elseif ch == "}" then
      depth = depth - 1
      if depth == 0 then
        return text:sub(start, i - 1), i + 1
      end
    end
    i = i + 1
  end
  return nil, pos
end

-- Parse a \captionof RawInline and return the caption inlines
local function parse_captionof(raw_text)
  local prefix = "\\captionof"
  if raw_text:sub(1, #prefix) ~= prefix then return nil end

  local pos = #prefix + 1
  while pos <= #raw_text and raw_text:sub(pos, pos):match("%s") do pos = pos + 1 end

  local float_type
  float_type, pos = extract_braced(raw_text, pos)
  if not float_type then return nil end

  while pos <= #raw_text and raw_text:sub(pos, pos):match("%s") do pos = pos + 1 end

  local caption_content
  caption_content, pos = extract_braced(raw_text, pos)
  if not caption_content then return nil end

  -- Strip \small
  caption_content = caption_content:gsub("^\\small%s*", "")

  -- Parse caption content as LaTeX
  local parsed = pandoc.read(caption_content, "latex").blocks
  local inlines = pandoc.List()
  for _, block in ipairs(parsed) do
    if block.content then
      inlines:extend(block.content)
    end
  end
  return inlines
end

-- Check if a block contains a figure (image + captionof)
local function extract_figure_from_block(block)
  -- Look for Div with class "center" or plain Para containing Image + captionof
  local para = nil
  if block.tag == "Div" and block.content then
    for _, sub in ipairs(block.content) do
      if sub.tag == "Para" then
        para = sub
        break
      end
    end
  elseif block.tag == "Para" then
    para = block
  end

  if not para or not para.content then return nil end

  local image = nil
  local caption_inlines = nil

  for _, inline in ipairs(para.content) do
    if inline.tag == "Image" then
      image = inline
    elseif inline.tag == "RawInline" and inline.format == "latex" then
      local cap = parse_captionof(inline.text)
      if cap then
        caption_inlines = cap
      end
    end
  end

  if image then
    return image, caption_inlines
  end
  return nil
end

-- ===========================================================================
-- Span filter: apply color for docx output
-- ===========================================================================
function Span(el)
  if FORMAT ~= "docx" then return nil end
  local style = el.attributes["style"]
  local color_name = extract_color_from_style(style)
  if not color_name then return nil end

  local color_hex = color_map[color_name]
  if not color_hex then return nil end

  local content_xml = collect_runs(el.content, color_hex, false, false)
  return pandoc.RawInline("openxml", content_xml)
end

-- ===========================================================================
-- Document-level filter: move figures to the end
-- ===========================================================================
function Pandoc(doc)
  if FORMAT ~= "docx" then return doc end

  local new_blocks = pandoc.List()
  local figure_blocks = pandoc.List()
  local fig_counter = 0

  for _, block in ipairs(doc.blocks) do
    local image, caption_inlines = extract_figure_from_block(block)
    if image then
      fig_counter = fig_counter + 1
      -- Build figure entry: image paragraph + caption paragraph
      local img_para = pandoc.Para({image})

      local cap_inlines = pandoc.List()
      cap_inlines:insert(pandoc.Strong({pandoc.Str(string.format("Figure %d: ", fig_counter))}))
      if caption_inlines then
        cap_inlines:extend(caption_inlines)
      end
      local cap_para = pandoc.Para(cap_inlines)

      figure_blocks:insert(img_para)
      figure_blocks:insert(cap_para)
    else
      new_blocks:insert(block)
    end
  end

  -- If we found figures, add a "Figures" section at the end
  if #figure_blocks > 0 then
    new_blocks:insert(pandoc.Header(1, "Figures"))
    new_blocks:extend(figure_blocks)
  end

  return pandoc.Pandoc(new_blocks, doc.meta)
end
